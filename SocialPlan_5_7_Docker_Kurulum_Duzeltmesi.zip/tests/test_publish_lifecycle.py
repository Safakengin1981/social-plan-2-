import os, sys, subprocess, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_publish_transition_security():
    with tempfile.TemporaryDirectory() as tmp:
        script=r'''
import os
from fastapi.testclient import TestClient
import app
c=TestClient(app.app)
r=c.post('/api/register',json={'business':'Test Company','email':'admin@example.org','password':'VeryStrongPassword123!'})
assert r.status_code==201,r.text
login=c.post('/api/login',json={'email':'admin@example.org','password':'VeryStrongPassword123!'})
assert login.status_code==200,login.text
h={'Authorization':'Bearer '+login.json()['token']}
with app.db() as db:
    bid=db.execute('SELECT id FROM businesses').fetchone()['id']
    uid=db.execute('SELECT id FROM users').fetchone()['id']
    db.execute('INSERT INTO posts(business_id,creator_id,caption,scheduled_at,status,created_at) VALUES(?,?,?,?,?,?)',(bid,uid,'test','2026-01-01T00:00:00+00:00','approved','2026-01-01T00:00:00+00:00'))
    pid=db.execute('SELECT id FROM posts').fetchone()['id']
    db.execute('INSERT INTO publish_jobs(business_id,post_id,status,created_at,updated_at) VALUES(?,?,?,?,?)',(bid,pid,'pending','2026-01-01T00:00:00+00:00','2026-01-01T00:00:00+00:00'))
    jid=db.execute('SELECT id FROM publish_jobs').fetchone()['id']
url=f'/api/admin/publishing-jobs/{jid}/transition'
def move(event,meta_id=None,note=None,expected=200):
    r=c.post(url,json={'event':event,'meta_id':meta_id,'note':note},headers=h)
    assert r.status_code==expected,(event,r.text)
    return r
move('publish_confirmed','123',expected=409)
move('container_created',expected=422)
move('container_created','123')
move('container_ready')
move('publish_started')
move('publish_uncertain',note='Network timeout')
move('publish_started',expected=409)
move('manual_cancel',expected=422)
move('publish_confirmed','456')
move('publish_confirmed','456',expected=409)
history=c.get(f'/api/admin/publishing-jobs/{jid}/history',headers=h)
assert history.status_code==200
assert len(history.json()['events'])==5
assert c.get(f'/api/admin/publishing-jobs/{jid}/history').status_code==401
assert c.get('/api/admin/publishing-jobs/99999/history',headers=h).status_code==404
'''
        env={**os.environ,'SOCIALPLAN_DB':str(Path(tmp)/'db.sqlite3'),'SOCIALPLAN_MEDIA':str(Path(tmp)/'media')}
        result=subprocess.run([sys.executable,'-c',script],cwd=ROOT,env=env,capture_output=True,text=True)
        assert result.returncode==0,result.stdout+'\n'+result.stderr
