import io
import json
import urllib.parse
import pytest
from instagram_publish import (create_image_container, get_container_status, publish_container,
                               PublishUncertain, MetaPublishError)

class Response:
    status=200
    def __init__(self, value): self.value=value
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,n): return json.dumps(self.value).encode()

def test_image_container_and_status():
    calls=[]
    def fake(req,timeout):
        calls.append(req)
        return Response({'id':'12345'} if req.get_method()=='POST' else {'status_code':'FINISHED'})
    assert create_image_container('123','https://example.com/p.jpg','Merhaba','secret',opener=fake)=='12345'
    assert get_container_status('12345','secret',opener=fake)=='FINISHED'
    assert calls[0].full_url=='https://graph.instagram.com/123/media'
    assert urllib.parse.parse_qs(calls[0].data.decode())['caption']==['Merhaba']
    assert 'secret' not in calls[0].full_url

def test_publish_and_ambiguous_result():
    assert publish_container('12','34','secret',opener=lambda req,timeout:Response({'id':'987'}))=='987'
    with pytest.raises(PublishUncertain):
        publish_container('12','34','secret',opener=lambda req,timeout:Response({}))
    def timeout(req,timeout): raise TimeoutError('network timeout')
    with pytest.raises(PublishUncertain): publish_container('12','34','secret',opener=timeout)

def test_invalid_media_and_meta_errors():
    with pytest.raises(ValueError): create_image_container('1','http://example.com/x.jpg','x','token')
    with pytest.raises(MetaPublishError):
        create_image_container('1','https://example.com/x.jpg','x','token',opener=lambda req,timeout:Response({'error':{'message':'denied'}}))
    with pytest.raises(MetaPublishError):
        get_container_status('123','token',opener=lambda req,timeout:Response({'status_code':'MYSTERY'}))
