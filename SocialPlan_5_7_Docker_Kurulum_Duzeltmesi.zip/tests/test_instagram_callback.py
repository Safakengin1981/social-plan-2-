import importlib
import os
import sys
from pathlib import Path
from fastapi.testclient import TestClient
from cryptography.fernet import Fernet

def test_callback_flow(tmp_path, monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_DB', str(tmp_path/'test.db'))
    monkeypatch.setenv('SOCIALPLAN_MEDIA', str(tmp_path/'media'))
    monkeypatch.setenv('INSTAGRAM_CLIENT_ID', '123456')
    monkeypatch.setenv('INSTAGRAM_CLIENT_SECRET', 'test-only-secret')
    monkeypatch.setenv('INSTAGRAM_REDIRECT_URI', 'https://example.org/api/instagram/callback')
    monkeypatch.setenv('SOCIALPLAN_TOKEN_KEY', Fernet.generate_key().decode())
    monkeypatch.setenv('INSTAGRAM_OAUTH_ENABLED', '1')
    sys.modules.pop('app', None)
    import app
    client = TestClient(app.app)
    reg = client.post('/api/register', json={'business':'Demo Business','email':'admin@example.org','password':'TestPassword123!'})
    assert reg.status_code in (200, 201), reg.text
    login = client.post('/api/login', json={'email':'admin@example.org','password':'TestPassword123!'})
    assert login.status_code == 200, login.text
    auth = {'Authorization':'Bearer '+login.json()['token']}
    start = client.post('/api/admin/instagram/authorization-url', json={'confirmation':True}, headers=auth)
    assert start.status_code == 200, start.text
    from urllib.parse import urlparse, parse_qs
    state = parse_qs(urlparse(start.json()['authorization_url']).query)['state'][0]
    monkeypatch.setattr(app, 'exchange_code', lambda *args: {'access_token':'short-token','user_id':'987654321'})
    monkeypatch.setattr(app, 'exchange_long_lived_token', lambda *args: {'access_token':'fake-test-token','expires_in':5184000})
    result = client.get('/api/instagram/callback', params={'state':state,'code':'test-code'})
    assert result.status_code == 200 and 'bağlandı' in result.text
    replay = client.get('/api/instagram/callback', params={'state':state,'code':'test-code'})
    assert replay.status_code == 400
    from token_vault import load_token
    with app.db() as c:
        assert load_token(c, 1, 'instagram') == 'fake-test-token'
        assert c.execute('SELECT instagram_user_id FROM instagram_accounts WHERE business_id=1').fetchone()[0] == '987654321'
    monkeypatch.setenv('INSTAGRAM_OAUTH_ENABLED','0')
    assert client.get('/api/instagram/callback', params={'state':'invalid','code':'x'}).status_code == 503
