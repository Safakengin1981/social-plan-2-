"""Check that a second process sees data created by the first process."""
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_database_survives_process_restart(tmp_path):
    env = os.environ.copy()
    env['SOCIALPLAN_DB'] = str(tmp_path / 'db' / 'socialplan.sqlite3')
    env['SOCIALPLAN_MEDIA'] = str(tmp_path / 'media')
    env.pop('SOCIALPLAN_REQUIRE_PERSISTENT', None)
    writer = "import app; from app import db; c=app.sqlite3.connect(app.DB); c.execute(\"INSERT INTO businesses(name) VALUES ('Restart test')\"); c.commit(); c.close(); print('written')"
    reader = "import app; from app import db; c=app.sqlite3.connect(app.DB); print(c.execute(\"SELECT count(*) FROM businesses WHERE name='Restart test'\").fetchone()[0]); c.close()"
    first = subprocess.run([sys.executable, '-c', writer], cwd=ROOT, env=env, text=True, capture_output=True, timeout=20)
    assert first.returncode == 0, first.stderr
    second = subprocess.run([sys.executable, '-c', reader], cwd=ROOT, env=env, text=True, capture_output=True, timeout=20)
    assert second.returncode == 0, second.stderr
    assert second.stdout.strip().endswith('1')
