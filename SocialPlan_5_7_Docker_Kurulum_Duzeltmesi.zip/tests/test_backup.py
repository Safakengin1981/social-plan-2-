import importlib.util
import sqlite3
from pathlib import Path
import zipfile
import json
import pytest

def load():
    spec=importlib.util.spec_from_file_location('sp_backup',Path(__file__).resolve().parents[1]/'backup.py')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def test_backup_and_integrity(tmp_path):
    b=load()
    b.DB=tmp_path/'source.sqlite3'
    b.MEDIA=tmp_path/'media'
    b.MEDIA.mkdir()
    (b.MEDIA/'photo.jpg').write_bytes(b'photo bytes')
    with sqlite3.connect(b.DB) as c:
        c.execute('CREATE TABLE items (name TEXT)')
        c.execute('INSERT INTO items VALUES (?)',('test',))
    target=tmp_path/'backup.zip'
    b.create(target)
    manifest=b.verify(target)
    assert set(manifest['files'])=={'database.sqlite3','media/photo.jpg'}
    with zipfile.ZipFile(target) as z:
        assert z.read('media/photo.jpg')==b'photo bytes'
        restored=tmp_path/'restored.sqlite3'
        restored.write_bytes(z.read('database.sqlite3'))
    with sqlite3.connect(restored) as c:
        assert c.execute('SELECT name FROM items').fetchone()[0]=='test'

def test_reject_modified_archive(tmp_path):
    b=load()
    b.DB=tmp_path/'source.sqlite3'
    b.MEDIA=tmp_path/'empty'
    with sqlite3.connect(b.DB) as c:c.execute('CREATE TABLE t(x)')
    good=tmp_path/'good.zip'; b.create(good)
    bad=tmp_path/'bad.zip'
    with zipfile.ZipFile(good) as source,zipfile.ZipFile(bad,'w') as target:
        for name in source.namelist():
            data=source.read(name)
            if name=='database.sqlite3':data=b'corrupt'
            target.writestr(name,data)
    with pytest.raises(ValueError,match='Checksum mismatch'):
        b.verify(bad)
