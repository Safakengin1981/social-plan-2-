import os,sys,subprocess,tempfile,json
from pathlib import Path
from datetime import datetime,timezone,timedelta
from fastapi.testclient import TestClient

def test_audit_business_isolation_and_roles():
    # Dedicated interpreter avoids contamination from other tests' module-level DB globals.
    code = r'''
import os,sys,json
from datetime import datetime,timezone,timedelta
from fastapi.testclient import TestClient
import app
c=TestClient(app.app)
def create(name,email):
    assert c.post('/api/register',json={'business':name,'email':email,'password':'long-test-password-123'}).status_code==201
    token=c.post('/api/login',json={'email':email,'password':'long-test-password-123'}).json()['token']
    return {'Authorization':'Bearer '+token}
a=create('Firma A','a@audit.test'); b=create('Firma B','b@audit.test')
when=(datetime.now(timezone.utc)+timedelta(days=2)).isoformat()
p=c.post('/api/posts',json={'caption':'hello','scheduled_at':when},headers=a)
assert p.status_code==201,p.text
pid=p.json()['id']
assert c.put(f'/api/posts/{pid}',json={'caption':'edited','scheduled_at':when},headers=a).status_code==200
assert c.post(f'/api/posts/{pid}/approve',headers=a).status_code==200
assert c.post(f'/api/posts/{pid}/cancel',headers=a).status_code==200
assert [x['action'] for x in c.get('/api/admin/audit',headers=a).json()]==['post_cancelled','post_approved','post_edited','post_created']
assert c.get('/api/admin/audit',headers=b).json()==[]
assert c.get('/api/admin/audit').status_code==401
assert c.get('/api/admin/audit?limit=201',headers=a).status_code==422
assert c.post('/api/members',json={'email':'ed@audit.test','password':'long-test-password-123','role':'editor'},headers=a).status_code==201
ed={'Authorization':'Bearer '+c.post('/api/login',json={'email':'ed@audit.test','password':'long-test-password-123'}).json()['token']}
assert c.get('/api/admin/audit',headers=ed).status_code==403
assert c.post(f'/api/posts/{pid}/cancel',headers=b).status_code==404
assert len(c.get('/api/admin/audit',headers=a).json())==4
'''
    with tempfile.TemporaryDirectory() as d:
        env=os.environ.copy();env['SOCIALPLAN_DB']=str(Path(d)/'db.sqlite');env['SOCIALPLAN_MEDIA']=str(Path(d)/'media');env.pop('SOCIALPLAN_REQUIRE_PERSISTENT',None)
        result=subprocess.run([sys.executable,'-c',code],cwd=str(Path(__file__).resolve().parents[1]),env=env,capture_output=True,text=True)
        assert result.returncode==0,result.stdout+result.stderr
