from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_publishing_ui_has_history_panel_and_prepare_action():
    html = (ROOT / 'static/index.html').read_text(encoding='utf-8')
    js = (ROOT / 'static/app.js').read_text(encoding='utf-8')
    assert 'id="publishJobs"' in html
    assert 'Yayın işi geçmişi' in html
    assert '/admin/publishing-jobs' in js
    assert '/admin/publishing-queue/${item.id}/prepare' in js
    assert 'İşlem geçmişi' in js
    assert 'SONUÇ BELİRSİZ' in js
    assert 'Meta doğrulaması yok' in js
    assert 'textContent=' in js
    assert 'innerHTML' not in js


def test_ui_has_no_publish_execution_control():
    js = (ROOT / 'static/app.js').read_text(encoding='utf-8')
    assert 'run_image_job' not in js
    assert 'publish_container(' not in js
    assert 'Otomatik tekrar yasak' not in js or 'otomatik tekrar yasak' in js
