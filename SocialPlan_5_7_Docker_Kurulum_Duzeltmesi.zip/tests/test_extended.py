import os,sys,tempfile,importlib,io
from pathlib import Path
from datetime import datetime,timezone,timedelta
from fastapi.testclient import TestClient

def test_media_edit_dashboard_and_export():
    with tempfile.TemporaryDirectory() as d:
        os.environ['SOCIALPLAN_DB']=str(Path(d)/'db.sqlite3')
        os.environ['SOCIALPLAN_MEDIA']=str(Path(d)/'media')
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]));sys.modules.pop('app',None)
        module=importlib.import_module('app');c=TestClient(module.app)
        assert c.get('/manifest.webmanifest').status_code==200
        assert c.get('/sw.js').status_code==200
        assert c.get('/icon.svg').status_code==200
        assert c.post('/api/register',json={'business':'RHM','email':'one@test.com','password':'abcdefghijklmnop'}).status_code==201
        token=c.post('/api/login',json={'email':'one@test.com','password':'abcdefghijklmnop'}).json()['token']
        h={'Authorization':'Bearer '+token}
        assert c.get('/api/dashboard',headers=h).json()['draft']==0
        assert c.post('/api/media',headers=h,files={'file':('evil.exe',b'bad','application/octet-stream')}).status_code==415
        media=c.post('/api/media',headers=h,files={'file':('pic.png',b'\x89PNG\r\n\x1a\n' + b'pngdata','image/png')})
        assert media.status_code==201,media.text
        mid=media.json()['id']
        assert c.get(f'/api/media/{mid}',headers=h).content==b'\x89PNG\r\n\x1a\n' + b'pngdata'
        assert c.get(f'/api/media/{mid}').status_code==401
        when=(datetime.now(timezone.utc)+timedelta(days=2)).isoformat()
        p=c.post('/api/posts',headers=h,json={'caption':'İlk metin','scheduled_at':when,'media_id':mid})
        assert p.status_code==201,p.text
        pid=p.json()['id']
        assert c.put(f'/api/posts/{pid}',headers=h,json={'caption':'Düzenlenmiş','scheduled_at':when}).status_code==200
        assert c.get('/api/dashboard',headers=h).json()['draft']==1
        assert 'Düzenlenmiş' in c.get('/api/posts/export.csv',headers=h).text
        assert c.get('/api/publishing/status',headers=h).json()['auto_publish'] is False
        assert c.post(f'/api/posts/{pid}/approve',headers=h).status_code==200
        assert c.put(f'/api/posts/{pid}',headers=h,json={'caption':'İzinsiz','scheduled_at':when}).status_code==404
        assert c.post('/api/register',json={'business':'Other','email':'two@test.com','password':'abcdefghijklmnop'}).status_code==201
        t2=c.post('/api/login',json={'email':'two@test.com','password':'abcdefghijklmnop'}).json()['token']
        h2={'Authorization':'Bearer '+t2}
        assert c.get(f'/api/media/{mid}',headers=h2).status_code==404
        assert c.post('/api/posts',headers=h2,json={'caption':'Deneme','scheduled_at':when,'media_id':mid}).status_code==404
        assert c.get('/api/posts/export.csv',headers=h2).text.count('Düzenlenmiş')==0
