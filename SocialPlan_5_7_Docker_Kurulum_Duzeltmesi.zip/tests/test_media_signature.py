import os, sys, tempfile, importlib
from pathlib import Path
from fastapi.testclient import TestClient

def test_media_signature_rejects_spoofed_files_without_residue():
    with tempfile.TemporaryDirectory() as d:
        os.environ['SOCIALPLAN_DB'] = str(Path(d)/'db.sqlite3')
        os.environ['SOCIALPLAN_MEDIA'] = str(Path(d)/'media')
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
        sys.modules.pop('app',None)
        m=importlib.import_module('app')
        c=TestClient(m.app)
        assert c.post('/api/register',json={'business':'Pilot','email':'media@test.com','password':'abcdefghijklmnop'}).status_code==201
        token=c.post('/api/login',json={'email':'media@test.com','password':'abcdefghijklmnop'}).json()['token']
        h={'Authorization':'Bearer '+token}
        for mime, data in [('image/png',b'<script>alert(1)</script>'),('image/jpeg',b'not-a-jpeg'),('image/webp',b'RIFFxxxxFAIL'),('video/mp4',b'not-an-mp4')]:
            r=c.post('/api/media',headers=h,files={'file':('spoofed',data,mime)})
            assert r.status_code==415,(mime,r.text)
        with m.db() as db:
            assert db.execute('SELECT COUNT(*) FROM media').fetchone()[0]==0
        assert not list((Path(d)/'media').rglob('*.*'))
        valid=b'\x89PNG\r\n\x1a\n'+b'PNG TEST PAYLOAD'
        r=c.post('/api/media',headers=h,files={'file':('real.png',valid,'image/png')})
        assert r.status_code==201,r.text
        assert c.get('/api/media/'+str(r.json()['id']),headers=h).content==valid

def test_signature_helpers():
    import importlib
    m=importlib.import_module('app')
    assert m.valid_media_signature('image/jpeg',b'\xff\xd8\xffDATA')
    assert m.valid_media_signature('image/webp',b'RIFFxxxxWEBPDATA')
    assert m.valid_media_signature('video/mp4',b'\x00\x00\x00\x18ftypisom')
    assert not m.valid_media_signature('video/mp4',b'\x00\x00\x00\x18ftypBAD!')
