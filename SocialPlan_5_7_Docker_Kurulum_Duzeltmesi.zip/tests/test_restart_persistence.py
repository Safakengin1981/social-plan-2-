"""Verify records survive independent application process restarts."""
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run_isolated(code, env):
    result = subprocess.run([sys.executable, '-c', code], cwd=ROOT, env=env,
                            capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stdout + '\n' + result.stderr
    return json.loads(result.stdout.strip())


def test_records_survive_server_process_restart(tmp_path):
    env = {**os.environ, 'SOCIALPLAN_DB': str(tmp_path / 'persistent.sqlite3'),
           'SOCIALPLAN_MEDIA': str(tmp_path / 'media'),
           'SOCIALPLAN_REQUIRE_PERSISTENT': '0'}
    first = run_isolated('''
import json
from fastapi.testclient import TestClient
from app import app
c=TestClient(app)
r=c.post('/api/register',json={'business':'Test Isletmesi','email':'restart@example.com','password':'StrongPass1234!'})
assert r.status_code==201,r.text
r=c.post('/api/login',json={'email':'restart@example.com','password':'StrongPass1234!'})
assert r.status_code==200,r.text
token=r.json()['token']
r=c.post('/api/posts',headers={'Authorization':'Bearer '+token},json={'caption':'Kalici test kaydi','scheduled_at':'2027-01-01T12:00:00+03:00'})
assert r.status_code==201,r.text
print(json.dumps({'created':r.json()['id']}))
''', env)
    second = run_isolated('''
import json
from fastapi.testclient import TestClient
from app import app
c=TestClient(app)
r=c.post('/api/login',json={'email':'restart@example.com','password':'StrongPass1234!'})
assert r.status_code==200,r.text
token=r.json()['token']
r=c.get('/api/posts',headers={'Authorization':'Bearer '+token})
assert r.status_code==200,r.text
assert len(r.json())==1,r.text
assert r.json()[0]['caption']=='Kalici test kaydi'
print(json.dumps({'found':r.json()[0]['id']}))
''', env)
    assert first['created'] == second['found']
