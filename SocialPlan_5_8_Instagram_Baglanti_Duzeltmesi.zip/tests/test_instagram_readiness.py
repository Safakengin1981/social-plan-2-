import os, sys, importlib
from pathlib import Path
from fastapi.testclient import TestClient

def test_instagram_readiness_is_admin_only_and_never_claims_connected(tmp_path, monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_DB',str(tmp_path/'test.sqlite3'))
    monkeypatch.setenv('SOCIALPLAN_MEDIA',str(tmp_path/'media'))
    monkeypatch.delenv('SOCIALPLAN_REQUIRE_PERSISTENT',raising=False)
    monkeypatch.setenv('INSTAGRAM_CLIENT_ID','123456789')
    monkeypatch.delenv('INSTAGRAM_CLIENT_SECRET',raising=False)
    monkeypatch.delenv('INSTAGRAM_REDIRECT_URI',raising=False)
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    sys.modules.pop('app',None)
    app=importlib.import_module('app')
    with TestClient(app.app) as c:
        r=c.post('/api/register',json={'business':'Test Isletme','email':'admin@example.com','password':'long-password-123'})
        assert r.status_code in (200,201),r.text
        login=c.post('/api/login',json={'email':'admin@example.com','password':'long-password-123'})
        assert login.status_code==200,login.text
        headers={'Authorization':'Bearer '+login.json()['token']}
        status=c.get('/api/admin/instagram-readiness',headers=headers)
        assert status.status_code==200,status.text
        data=status.json()
        assert data['connected'] is False and data['ready'] is False
        assert data['configured']['INSTAGRAM_CLIENT_ID'] is True
        assert data['configured']['INSTAGRAM_CLIENT_SECRET'] is False
        assert c.get('/api/admin/instagram-readiness').status_code==401
        member=c.post('/api/members',json={'email':'editor@example.com','password':'long-password-123','role':'editor'},headers=headers)
        assert member.status_code in (200,201),member.text
        ed=c.post('/api/login',json={'email':'editor@example.com','password':'long-password-123'}).json()['token']
        assert c.get('/api/admin/instagram-readiness',headers={'Authorization':'Bearer '+ed}).status_code==403
        assert 'publishQueue' in c.get('/').text
