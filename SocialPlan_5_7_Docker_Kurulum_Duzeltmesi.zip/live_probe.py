"""Read-only, unauthenticated HTTP checks for an explicitly supplied deployment URL.

Never registers users, uploads media, modifies data, or logs secrets.
"""
import argparse
import json
import ssl
import urllib.error
import urllib.parse
import urllib.request


class ProbeError(ValueError):
    pass


def validate_base(raw, allow_local_http=False):
    p = urllib.parse.urlsplit(raw)
    if p.username or p.password or p.query or p.fragment or p.path not in ('', '/'):
        raise ProbeError('Yalnızca sunucu kök adresini girin; kullanıcı bilgisi, yol ve sorgu eklemeyin.')
    if not p.hostname:
        raise ProbeError('Geçerli bir sunucu adresi gerekli.')
    local = p.hostname in ('localhost', '127.0.0.1', '::1')
    if p.scheme != 'https' and not (allow_local_http and p.scheme == 'http' and local):
        raise ProbeError('HTTPS zorunludur; HTTP yalnızca açıkça izin verilen localhost testinde kullanılabilir.')
    return f'{p.scheme}://{p.netloc}'


def run_probe(base, opener=None, allow_local_http=False, timeout=8):
    base = validate_base(base, allow_local_http)
    opener = opener or urllib.request.urlopen
    results = []
    for path, expected_type in [('/api/health', 'json'), ('/api/ready', 'json'), ('/', 'html'), ('/app.js', 'javascript')]:
        item = {'path': path, 'ok': False}
        try:
            request = urllib.request.Request(base + path, headers={'User-Agent':'SocialPlan-readonly-probe/1.0', 'Accept':'*/*'}, method='GET')
            with opener(request, timeout=timeout) as response:
                status = response.status
                content_type = response.headers.get('Content-Type', '').lower()
                payload = response.read(32768)
            item['http_status'] = status
            if expected_type == 'json':
                data = json.loads(payload)
                item['ok'] = status == 200 and isinstance(data, dict) and data.get('status') == ('ok' if path == '/api/health' else 'ready')
                if path == '/api/health' and isinstance(data, dict):
                    item['version'] = str(data.get('version', 'unknown'))[:32]
            elif expected_type == 'html':
                item['ok'] = status == 200 and ('text/html' in content_type or b'<!doctype html' in payload.lower())
            else:
                item['ok'] = status == 200 and (b'function ' in payload or b'addEventListener' in payload or b'const ' in payload)
        except (urllib.error.URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
            item['error_type'] = type(exc).__name__
        results.append(item)
    return {'base':base, 'ready':all(item['ok'] for item in results), 'checks':results,
            'limits':'Bu kontrol salt okunurdur; disk kalıcılığını, yedeklemeyi, tarayıcı davranışını veya Instagram paylaşımını kanıtlamaz.'}


def main():
    parser = argparse.ArgumentParser(description='SocialPlan canlı sunucu salt okunur sağlık kontrolü')
    parser.add_argument('url', help='Örn. https://ornek.onrender.com')
    parser.add_argument('--allow-local-http', action='store_true', help='Yalnızca localhost HTTP testine izin verir')
    args = parser.parse_args()
    try:
        report = run_probe(args.url, allow_local_http=args.allow_local_http)
    except ProbeError as exc:
        parser.error(str(exc))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['ready'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
