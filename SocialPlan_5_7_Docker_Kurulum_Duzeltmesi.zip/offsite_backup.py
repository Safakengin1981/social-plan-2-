"""Off-site backup to an S3-compatible bucket. Never stores credentials in code."""
import argparse
import os
import tempfile
from pathlib import Path
from datetime import datetime, timezone

from backup import create as create_backup, verify as verify_backup


def run(bucket=None, prefix='socialplan', client=None):
    bucket = bucket or os.environ.get('SOCIALPLAN_BACKUP_BUCKET')
    if not bucket:
        raise ValueError('SOCIALPLAN_BACKUP_BUCKET gerekli')
    if client is None:
        try:
            import boto3
        except ImportError as exc:
            raise RuntimeError('boto3 yükleyin: pip install boto3') from exc
        client = boto3.client('s3', endpoint_url=os.environ.get('SOCIALPLAN_S3_ENDPOINT') or None)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    key = f"{prefix.strip('/')}/{stamp}.zip"
    with tempfile.TemporaryDirectory() as td:
        archive = Path(td) / 'backup.zip'
        create_backup(archive)
        verify_backup(archive)
        client.upload_file(str(archive), bucket, key, ExtraArgs={'ServerSideEncryption': 'AES256'})
        # Download and verify independently, not merely trust upload response.
        downloaded = Path(td) / 'downloaded.zip'
        client.download_file(bucket, key, str(downloaded))
        verify_backup(downloaded)
    return {'bucket': bucket, 'key': key, 'verified': True}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--bucket', default=None)
    p.add_argument('--prefix', default='socialplan')
    a = p.parse_args()
    result = run(a.bucket, a.prefix)
    print('Uzak yedek doğrulandı:', result['key'])
