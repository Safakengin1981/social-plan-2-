from zipfile import ZipFile
from release_check import check_archive


def test_release_rejects_database_and_secret(tmp_path):
    archive = tmp_path / 'unsafe.zip'
    with ZipFile(archive, 'w') as z:
        for name in ('app.py', 'requirements.txt', 'Dockerfile', 'README.md', 'static/index.html', 'static/app.js'):
            z.writestr(name, 'sample')
        z.writestr('data/socialplan.sqlite3', 'test')
        z.writestr('.env', 'SECRET=test')
    issues = check_archive(archive)
    assert any('socialplan.sqlite3' in issue for issue in issues)
    assert any('.env' in issue for issue in issues)


def test_release_accepts_clean_archive(tmp_path):
    archive = tmp_path / 'clean.zip'
    with ZipFile(archive, 'w') as z:
        for name in ('app.py', 'requirements.txt', 'Dockerfile', 'README.md', 'static/index.html', 'static/app.js'):
            z.writestr(name, 'sample')
    assert check_archive(archive) == []
