"""Instagram Login OAuth code exchange. Network calls are isolated for mocking."""
import json
import urllib.parse
import urllib.request
import urllib.error

TOKEN_ENDPOINT = 'https://api.instagram.com/oauth/access_token'

def exchange_code(code, client_id, client_secret, redirect_uri):
    payload = urllib.parse.urlencode({
        'client_id': client_id, 'client_secret': client_secret,
        'grant_type': 'authorization_code', 'redirect_uri': redirect_uri,
        'code': code,
    }).encode('utf-8')
    request = urllib.request.Request(TOKEN_ENDPOINT, data=payload, method='POST',
                                     headers={'Content-Type': 'application/x-www-form-urlencoded'})
    with urllib.request.urlopen(request, timeout=12) as response:
        if response.status != 200:
            raise ValueError('Meta token isteği başarısız')
        result = json.loads(response.read(32768))
    if not isinstance(result, dict) or not isinstance(result.get('access_token'), str) or not result['access_token'] or not str(result.get('user_id', '')).isdigit():
        raise ValueError('Meta yanıtında geçerli token veya hesap kimliği yok')
    return {'access_token': result['access_token'], 'user_id': str(result['user_id'])}

LONG_LIVED_ENDPOINT = 'https://graph.instagram.com/access_token'
REFRESH_ENDPOINT = 'https://graph.instagram.com/refresh_access_token'

def _read_json(url):
    request = urllib.request.Request(url, method='GET', headers={'Accept':'application/json'})
    with urllib.request.urlopen(request, timeout=12) as response:
        if response.status != 200:
            raise ValueError('Meta token servisi hata verdi')
        data = json.loads(response.read(32768))
    if not isinstance(data, dict) or not isinstance(data.get('access_token'), str) or not data['access_token']:
        raise ValueError('Meta token yanıtı geçersiz')
    seconds = data.get('expires_in')
    if type(seconds) is not int or not 0 < seconds <= 10_000_000:
        raise ValueError('Meta token geçerlilik süresi geçersiz')
    return {'access_token':data['access_token'], 'expires_in':seconds}

def exchange_long_lived_token(short_token, client_secret):
    if not short_token or not client_secret:
        raise ValueError('Token veya uygulama sırrı eksik')
    query=urllib.parse.urlencode({'grant_type':'ig_exchange_token','client_secret':client_secret,'access_token':short_token})
    return _read_json(LONG_LIVED_ENDPOINT+'?'+query)

def refresh_long_lived_token(long_token):
    if not long_token:
        raise ValueError('Yenilenecek token eksik')
    query=urllib.parse.urlencode({'grant_type':'ig_refresh_token','access_token':long_token})
    return _read_json(REFRESH_ENDPOINT+'?'+query)
