"""Opt-in Instagram image publishing orchestration.

This module is NOT invoked by a scheduler or an HTTP endpoint. It must only be
called by a trusted worker after operator configuration and approval.
"""
from datetime import datetime, timezone
from urllib.parse import urlsplit
import ipaddress
from instagram_publish import PublishUncertain, MetaPublishError


def validate_media_url(url):
    parts = urlsplit(url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password or parts.fragment:
        raise ValueError('Herkese açık, kimlik bilgisi içermeyen HTTPS medya URL gerekli')
    host = parts.hostname.rstrip('.').lower()
    if host in ('localhost',) or host.endswith(('.localhost', '.local', '.internal', '.test', '.invalid')):
        raise ValueError('Yerel medya adresi kullanılamaz')
    try:
        ipaddress.ip_address(host.strip('[]'))
    except ValueError:
        pass
    else:
        raise ValueError('Medya URL için IP adresi kullanılamaz; doğrulanmış alan adı gerekli')
    if parts.port not in (None, 443):
        raise ValueError('Medya URL yalnızca standart HTTPS portunu kullanabilir')
    return url


def run_image_job(conn, *, job_id, business_id, instagram_user_id, token, media_url, transport, now=None):
    """Execute one approved image job; persist every critical transition.

    No automatic retries: network ambiguity enters 'uncertain' and needs manual
    reconciliation. Caller owns transaction boundaries and worker serialization.
    """
    validate_media_url(media_url)
    now = now or datetime.now(timezone.utc).isoformat()
    row = conn.execute('''SELECT j.status,p.status post_status,p.caption,p.media_id
        FROM publish_jobs j JOIN posts p ON p.id=j.post_id AND p.business_id=j.business_id
        WHERE j.id=? AND j.business_id=?''', (job_id,business_id)).fetchone()
    if not row: raise ValueError('Yayın işi bulunamadı')
    if row['status'] != 'pending': raise ValueError('İş zaten işlenmiş; otomatik tekrar yasak')
    if row['post_status'] != 'approved' or not row['media_id']:
        raise ValueError('Yalnızca onaylı, medyalı içerikler yayımlanabilir')
    # Durable claim: caller must commit immediately before contacting Meta.
    updated = conn.execute('''UPDATE publish_jobs SET status='creating_container',updated_at=?
        WHERE id=? AND business_id=? AND status='pending' ''',(now,job_id,business_id))
    if updated.rowcount != 1: raise ValueError('Yayın işi başka çalışan tarafından alındı')
    conn.commit()
    try:
        container_id=transport.create_image_container(instagram_user_id,media_url,row['caption'],token)
    except Exception as exc:
        # Even a container creation request may have succeeded remotely.
        conn.execute('UPDATE publish_jobs SET status=?,last_error=?,updated_at=? WHERE id=? AND business_id=?',
                     ('uncertain','Medya hazırlama sonucu doğrulanamadı',now,job_id,business_id))
        conn.commit()
        return {'status':'uncertain','reason':'container_request_unconfirmed'}
    conn.execute('UPDATE publish_jobs SET status=?,container_id=?,updated_at=? WHERE id=? AND business_id=?',
                 ('container_created',container_id,now,job_id,business_id))
    conn.commit()
    try:
        status=transport.get_container_status(container_id,token)
    except Exception:
        return {'status':'container_created','reason':'status_check_failed','container_id':container_id}
    if status != 'FINISHED':
        return {'status':'container_created','reason':'media_not_ready','container_id':container_id,'meta_status':status}
    conn.execute('UPDATE publish_jobs SET status=?,updated_at=? WHERE id=? AND business_id=?',
                 ('publishing',now,job_id,business_id))
    conn.commit()
    try:
        media_id=transport.publish_container(instagram_user_id,container_id,token)
    except Exception:
        conn.execute('UPDATE publish_jobs SET status=?,last_error=?,updated_at=? WHERE id=? AND business_id=?',
                     ('uncertain','Yayın sonucu belirsiz; tekrar gönderme',now,job_id,business_id))
        conn.commit()
        return {'status':'uncertain','reason':'publish_result_unconfirmed','container_id':container_id}
    conn.execute('UPDATE publish_jobs SET status=?,published_media_id=?,last_error=NULL,updated_at=? WHERE id=? AND business_id=?',
                 ('published',media_id,now,job_id,business_id))
    conn.commit()
    return {'status':'published','media_id':media_id,'container_id':container_id}


def inspect_interrupted_jobs(conn, *, business_id):
    """Read-only inspection. Never retry a job after a crash or unknown Meta result."""
    rows=conn.execute("""SELECT id,post_id,status,container_id,published_media_id,updated_at
        FROM publish_jobs WHERE business_id=? AND status IN
        ('creating_container','container_created','publishing','uncertain') ORDER BY id""",(business_id,)).fetchall()
    return [dict(row) for row in rows]
