"""Guard against deploying an image with missing Python modules."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_dockerfile_copies_all_local_python_modules():
    docker = (ROOT / 'Dockerfile').read_text()
    copied = set()
    for line in docker.splitlines():
        if line.startswith('COPY '):
            copied.update(part for part in line.split()[1:-1] if part.endswith('.py'))
    modules = {p.stem: p.name for p in ROOT.glob('*.py')}
    needed = {'app'}
    queue = ['app']
    while queue:
        module = queue.pop()
        tree = ast.parse((ROOT / modules[module]).read_text())
        for node in ast.walk(tree):
            candidates = []
            if isinstance(node, ast.Import):
                candidates = [alias.name.split('.')[0] for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                candidates = [node.module.split('.')[0]]
            for candidate in candidates:
                if candidate in modules and candidate not in needed:
                    needed.add(candidate)
                    queue.append(candidate)
    missing = {modules[name] for name in needed} - copied
    assert not missing, f'Runtime imports absent from Docker image: {sorted(missing)}'


def test_dockerignore_excludes_mutable_and_secret_files():
    ignored = (ROOT / '.dockerignore').read_text().splitlines()
    for pattern in ('data/', '.env', '*.sqlite3', 'tests/', '.git'):
        assert pattern in ignored
