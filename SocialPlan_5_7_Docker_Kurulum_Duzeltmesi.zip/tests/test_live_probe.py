import io
import json
from email.message import Message
from unittest.mock import Mock
import pytest
from live_probe import ProbeError, run_probe, validate_base


class Response:
    def __init__(self, data, content_type='application/json', status=200):
        self.data = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.status = status
        self.headers = Message()
        self.headers['Content-Type'] = content_type
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, count): return self.data[:count]


def fake_open(request, timeout):
    path = request.full_url.split('.test')[-1]
    assert request.get_method() == 'GET'
    if path == '/api/health': return Response({'status':'ok','version':'5.6'})
    if path == '/api/ready': return Response({'status':'ready'})
    if path == '/': return Response(b'<!doctype html>', 'text/html')
    if path == '/app.js': return Response(b'document.addEventListener("DOMContentLoaded", () => {})', 'application/javascript')
    raise AssertionError(path)


def test_live_probe_success_read_only():
    result = run_probe('https://example.test', opener=fake_open)
    assert result['ready'] and len(result['checks']) == 4
    assert result['checks'][0]['version'] == '5.6'


def test_live_probe_reports_unready_without_mutation():
    def open_unready(request, timeout):
        if request.full_url.endswith('/api/ready'):
            return Response({'status':'not-ready'}, status=503)
        return fake_open(request, timeout)
    result = run_probe('https://example.test', opener=open_unready)
    assert not result['ready']
    assert result['checks'][1]['http_status'] == 503


@pytest.mark.parametrize('url', ['http://example.test','https://user:pass@example.test',
                                   'https://example.test/api/health','https://example.test/?token=x',
                                   'file:///tmp/file','https://example.test/#frag'])
def test_live_probe_rejects_unsafe_urls(url):
    with pytest.raises(ProbeError): validate_base(url)


def test_live_probe_local_http_explicit_only():
    assert validate_base('http://127.0.0.1:10000', allow_local_http=True) == 'http://127.0.0.1:10000'
    with pytest.raises(ProbeError): validate_base('http://example.test', allow_local_http=True)
