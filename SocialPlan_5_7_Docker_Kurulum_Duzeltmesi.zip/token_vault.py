"""Encrypted, business-scoped credential vault groundwork; no Meta API connection.

The key is supplied externally as a Fernet key via SOCIALPLAN_TOKEN_KEY.
Do not store this key on the same ephemeral disk as the database.
"""
import os
import sqlite3
from datetime import datetime, timezone
from cryptography.fernet import Fernet, InvalidToken


def cipher_from_environment():
    key = os.environ.get('SOCIALPLAN_TOKEN_KEY', '')
    if not key:
        raise RuntimeError('SOCIALPLAN_TOKEN_KEY eksik; token kaydı kapalı')
    try:
        return Fernet(key.encode('ascii'))
    except (ValueError, TypeError, UnicodeError) as exc:
        raise RuntimeError('SOCIALPLAN_TOKEN_KEY geçersiz') from exc


def setup_vault(connection: sqlite3.Connection):
    connection.execute('''CREATE TABLE IF NOT EXISTS integration_credentials (
        business_id INTEGER NOT NULL,
        provider TEXT NOT NULL,
        encrypted_token BLOB NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (business_id, provider),
        FOREIGN KEY (business_id) REFERENCES businesses(id)
    )''')


def save_token(connection, business_id: int, provider: str, token: str):
    if not isinstance(business_id, int) or business_id <= 0:
        raise ValueError('İşletme kimliği geçersiz')
    if provider != 'instagram':
        raise ValueError('Desteklenmeyen sağlayıcı')
    if not isinstance(token, str) or not token or len(token) > 8192:
        raise ValueError('Token geçersiz')
    encrypted = cipher_from_environment().encrypt(token.encode('utf-8'))
    connection.execute('''INSERT INTO integration_credentials
        (business_id, provider, encrypted_token, updated_at) VALUES (?, ?, ?, ?)
        ON CONFLICT(business_id, provider) DO UPDATE SET
        encrypted_token=excluded.encrypted_token, updated_at=excluded.updated_at''',
        (business_id, provider, encrypted, datetime.now(timezone.utc).isoformat()))


def load_token(connection, business_id: int, provider: str):
    row = connection.execute('''SELECT encrypted_token FROM integration_credentials
        WHERE business_id=? AND provider=?''', (business_id, provider)).fetchone()
    if row is None:
        return None
    try:
        return cipher_from_environment().decrypt(row[0]).decode('utf-8')
    except InvalidToken as exc:
        raise RuntimeError('Token çözülemedi; anahtar değişmiş veya veri bozulmuş') from exc


def delete_token(connection, business_id: int, provider: str):
    return connection.execute('DELETE FROM integration_credentials WHERE business_id=? AND provider=?',
                              (business_id, provider)).rowcount
