import os,sys,tempfile,importlib
from pathlib import Path
from datetime import datetime,timezone,timedelta
from fastapi.testclient import TestClient

def test_full_flow():
    with tempfile.TemporaryDirectory() as d:
        os.environ['SOCIALPLAN_DB']=str(Path(d)/'test.db')
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
        sys.modules.pop('app',None)
        a=importlib.import_module('app')
        c=TestClient(a.app)
        assert c.get('/').status_code==200
        assert c.get('/app.js').status_code==200
        assert c.get('/api/health').json()['status']=='ok'
        user={'business':'RHM Test','email':'admin@example.test','password':'test-password-123'}
        assert c.post('/api/register',json=user).status_code==201
        assert c.post('/api/register',json=user).status_code==409
        assert c.post('/api/login',json={'email':user['email'],'password':'bad'}).status_code==401
        r=c.post('/api/login',json={'email':user['email'],'password':user['password']})
        assert r.status_code==200
        h={'Authorization':'Bearer '+r.json()['token']}
        assert c.get('/api/me',headers=h).json()['role']=='admin'
        assert c.get('/api/posts').status_code==401
        p=c.post('/api/posts',json={'caption':'Test içerik','scheduled_at':(datetime.now(timezone.utc)+timedelta(days=1)).isoformat()},headers=h)
        assert p.status_code==201,p.text
        pid=p.json()['id']
        assert c.get('/api/posts',headers=h).json()[0]['status']=='draft'
        assert c.post(f'/api/posts/{pid}/approve',headers=h).json()=={'status':'approved','published':False}
        assert c.post(f'/api/posts/{pid}/cancel',headers=h).json()['status']=='cancelled'
        member={'email':'editor@example.test','password':'test-password-456','role':'editor'}
        assert c.post('/api/members',json=member,headers=h).status_code==201
        r=c.post('/api/login',json={'email':member['email'],'password':member['password']})
        he={'Authorization':'Bearer '+r.json()['token']}
        assert c.get('/api/members',headers=he).status_code==403
        assert c.post(f'/api/posts/{pid}/approve',headers=he).status_code==403
        assert c.post('/api/logout',headers=h).status_code==200
        assert c.get('/api/me',headers=h).status_code==401
        other={'business':'Başka Şirket','email':'other@example.test','password':'test-password-789'}
        assert c.post('/api/register',json=other).status_code==201
        ro=c.post('/api/login',json={'email':other['email'],'password':other['password']})
        ho={'Authorization':'Bearer '+ro.json()['token']}
        assert c.get('/api/posts',headers=ho).json()==[]
        assert c.post(f'/api/posts/{pid}/cancel',headers=ho).status_code==404
