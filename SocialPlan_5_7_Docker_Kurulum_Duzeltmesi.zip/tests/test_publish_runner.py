import sqlite3
import pytest
from publish_runner import run_image_job,validate_media_url

class FakeTransport:
    def __init__(self, fail=False, ready=True):self.calls=[];self.fail=fail;self.ready=ready
    def create_image_container(self,*args):self.calls.append('create');return '123'
    def get_container_status(self,*args):self.calls.append('status');return 'FINISHED' if self.ready else 'IN_PROGRESS'
    def publish_container(self,*args):
        self.calls.append('publish')
        if self.fail:raise TimeoutError()
        return '456'

def database():
    c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row
    c.executescript('CREATE TABLE posts(id INTEGER PRIMARY KEY,business_id INTEGER,status TEXT,caption TEXT,media_id INTEGER);CREATE TABLE publish_jobs(id INTEGER PRIMARY KEY,business_id INTEGER,post_id INTEGER,status TEXT,updated_at TEXT,last_error TEXT,container_id TEXT,published_media_id TEXT);INSERT INTO posts VALUES(1,10,"approved","hello",5);INSERT INTO publish_jobs (id,business_id,post_id,status,updated_at,last_error) VALUES(1,10,1,"pending",NULL,NULL);')
    return c

def test_publish_success_and_no_duplicate():
    c=database(); t=FakeTransport()
    assert run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)['status']=='published'
    assert t.calls==['create','status','publish']
    with pytest.raises(ValueError):run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)
    assert len(t.calls)==3

def test_uncertain_never_retry():
    c=database();t=FakeTransport(fail=True)
    assert run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)['status']=='uncertain'
    with pytest.raises(ValueError):run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)
    assert t.calls.count('publish')==1

def test_waiting_media_and_tenant_isolation():
    c=database();t=FakeTransport(ready=False)
    with pytest.raises(ValueError):run_image_job(c,job_id=1,business_id=11,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)
    assert not t.calls
    assert run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)['status']=='container_created'
    assert 'publish' not in t.calls

def test_url_validation():
    for url in ('http://example.org/a','https://localhost/a','https://user:pass@example.org/a','file:///x'):
        with pytest.raises(ValueError):validate_media_url(url)


def test_meta_identifiers_persisted():
    c=database();t=FakeTransport()
    run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)
    row=c.execute('SELECT container_id,published_media_id FROM publish_jobs WHERE id=1').fetchone()
    assert row['container_id']=='123' and row['published_media_id']=='456'

def test_interrupted_jobs_are_inspectable_but_not_retried():
    from publish_runner import inspect_interrupted_jobs
    c=database();t=FakeTransport(ready=False)
    run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)
    assert inspect_interrupted_jobs(c,business_id=10)[0]['container_id']=='123'
    assert inspect_interrupted_jobs(c,business_id=11)==[]
    with pytest.raises(ValueError):run_image_job(c,job_id=1,business_id=10,instagram_user_id='100',token='secret',media_url='https://cdn.example.org/image.jpg',transport=t)
