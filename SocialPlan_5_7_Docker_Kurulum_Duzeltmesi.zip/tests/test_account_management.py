import sys
from fastapi.testclient import TestClient
from cryptography.fernet import Fernet

def test_account_status_and_disconnect(tmp_path, monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_DB',str(tmp_path/'db.sqlite'))
    monkeypatch.setenv('SOCIALPLAN_MEDIA',str(tmp_path/'media'))
    monkeypatch.setenv('SOCIALPLAN_TOKEN_KEY',Fernet.generate_key().decode())
    sys.modules.pop('app',None)
    import app
    client=TestClient(app.app)
    def create(name,email):
        r=client.post('/api/register',json={'business':name,'email':email,'password':'LongPassword123!'})
        assert r.status_code in (200,201),r.text
        r=client.post('/api/login',json={'email':email,'password':'LongPassword123!'})
        assert r.status_code==200
        return {'Authorization':'Bearer '+r.json()['token']}
    a=create('Company A','a@demo.test')
    b=create('Company B','b@demo.test')
    assert client.get('/api/admin/instagram/account',headers=a).json()['status']=='not_connected'
    with app.db() as c:
        from token_vault import save_token
        save_token(c,1,'instagram','fake-token')
        c.execute('INSERT INTO instagram_accounts(business_id,instagram_user_id,connected_at) VALUES(1,?,?)',('123','2026-01-01T00:00:00+00:00'))
    status=client.get('/api/admin/instagram/account',headers=a)
    assert status.status_code==200 and status.json()['status']=='stored_unverified'
    assert 'fake-token' not in status.text
    assert client.get('/api/admin/instagram/account',headers=b).json()['status']=='not_connected'
    assert client.delete('/api/admin/instagram/account',headers=b).status_code==200
    assert client.get('/api/admin/instagram/account',headers=a).json()['connected'] is True
    assert client.delete('/api/admin/instagram/account',headers=a).status_code==200
    assert client.get('/api/admin/instagram/account',headers=a).json()['status']=='not_connected'
