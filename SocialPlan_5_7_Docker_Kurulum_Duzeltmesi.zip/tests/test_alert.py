import json
from datetime import datetime, timezone, timedelta
from backup_job import execute, notify_failure

def test_alert_on_failure(tmp_path):
    seen=[]
    def fail(): raise RuntimeError('unavailable')
    record=execute(fail,tmp_path/'state.json',lambda r: seen.append(r) or True)
    assert record['status']=='failure' and record['alert_sent'] is True and len(seen)==1

def test_alert_failure_does_not_mask_backup_failure(tmp_path):
    def fail(): raise RuntimeError('unavailable')
    def bad_alert(r): raise RuntimeError('webhook down')
    record=execute(fail,tmp_path/'state.json',bad_alert)
    assert record['status']=='failure' and record['alert_sent'] is False
    assert json.loads((tmp_path/'state.json').read_text())['status']=='failure'

def test_success_does_not_alert(tmp_path):
    called=[]
    record=execute(lambda:{'verified':True,'key':'a.zip'},tmp_path/'state.json',lambda r: called.append(r))
    assert record['status']=='success' and not called

def test_webhook_https_only(monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_ALERT_WEBHOOK','http://example.com/webhook')
    try: notify_failure({'time_utc':'2026-01-01T00:00:00+00:00'})
    except ValueError: pass
    else: assert False, 'HTTP webhook must be rejected'
