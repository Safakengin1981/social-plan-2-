from pathlib import Path

def test_backup_dashboard_is_admin_only_and_refreshable():
    root=Path(__file__).resolve().parents[1]
    html=(root/'static/index.html').read_text(encoding='utf-8')
    js=(root/'static/app.js').read_text(encoding='utf-8')
    assert 'id="backupPanel"' in html
    assert 'id="backupText"' in html
    assert 'id="backupRefresh"' in html
    assert "role!=='admin'" in js
    assert "api('/admin/backup-status')" in js
    assert "['backupRefresh',backupHealth]" in js
