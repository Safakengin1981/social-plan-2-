"""Optional in-process daily backup scheduler, designed for one web worker.

Enable with SOCIALPLAN_AUTO_BACKUP=1. Runs at 23:30 Europe/Istanbul.
An OS file lock prevents concurrent jobs sharing the same persistent disk.
"""
import fcntl
import json
import os
import threading
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from backup_job import execute

ISTANBUL = ZoneInfo('Europe/Istanbul')


def status_path():
    return Path(os.environ.get('SOCIALPLAN_BACKUP_STATUS', '/tmp/socialplan-backup-status.json'))


def due(now=None, status=None):
    now = now or datetime.now(ISTANBUL)
    local = now.astimezone(ISTANBUL)
    slot = local.replace(hour=23, minute=30, second=0, microsecond=0)
    if local < slot:
        slot -= timedelta(days=1)
    # Do not backfill an old slot if the application starts before today's
    # scheduled run, except for the overnight retry window.
    if local < slot + timedelta(hours=1) and local.date() != slot.date():
        return False
    if local.date() != slot.date() and local - slot > timedelta(hours=6):
        return False
    if status:
        try:
            last = datetime.fromisoformat(status['time_utc']).astimezone(ISTANBUL)
            if status.get('status') == 'success' and last >= slot:
                return False
            if status.get('status') == 'failure' and last >= slot and local - last < timedelta(hours=1):
                return False
        except (ValueError, TypeError, KeyError):
            pass
    return True


def tick(now=None, runner=execute):
    path = status_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_suffix('.lock')
    with lock_path.open('a+b') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return 'locked'
        try:
            try:
                status = json.loads(path.read_text(encoding='utf-8'))
            except (FileNotFoundError, ValueError, OSError):
                status = None
            if not due(now, status):
                return 'not_due'
            result = runner(status_file=path)
            return result['status']
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def start():
    if os.environ.get('SOCIALPLAN_AUTO_BACKUP') != '1':
        return
    def loop():
        while True:
            try:
                tick()
            except Exception as exc:
                # Avoid logging credentials or webhook URLs from exception strings.
                print('SocialPlan: yedekleme zamanlayıcısı hatası:', type(exc).__name__, flush=True)
            threading.Event().wait(300)
    threading.Thread(target=loop, name='socialplan-backup', daemon=True).start()

if __name__ == '__main__':
    print(tick())
