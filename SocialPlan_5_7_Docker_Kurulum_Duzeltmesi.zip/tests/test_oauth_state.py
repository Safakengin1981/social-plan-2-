import importlib,sys
from pathlib import Path
from fastapi.testclient import TestClient

def test_oauth_state_single_use_isolation(tmp_path,monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_DB',str(tmp_path/'db.sqlite3'))
    monkeypatch.setenv('SOCIALPLAN_MEDIA',str(tmp_path/'media'))
    monkeypatch.delenv('SOCIALPLAN_REQUIRE_PERSISTENT',raising=False)
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    sys.modules.pop('app',None)
    app=importlib.import_module('app')
    with TestClient(app.app) as c:
        def signup(b,e):
            assert c.post('/api/register',json={'business':b,'email':e,'password':'Password2026Strong!'}).status_code==201
            token=c.post('/api/login',json={'email':e,'password':'Password2026Strong!'}).json()['token']
            return {'Authorization':'Bearer '+token}
        a=signup('Business A','a@example.com');b=signup('Business B','b@example.com')
        url='/api/admin/instagram/oauth-state'
        assert c.post(url,json={'confirmation':True}).status_code==401
        assert c.post(url,json={'confirmation':False},headers=a).status_code==422
        state=c.post(url,json={'confirmation':True},headers=a)
        assert state.status_code==200,state.text
        payload=state.json()
        assert payload['connected'] is False and payload['authorization_url'] is None
        verify=url+'/verify'
        assert c.post(verify,json={'state':payload['state']},headers=b).status_code==400
        assert c.post(verify,json={'state':payload['state']},headers=a).json()=={'state_verified':True,'connected':False,'message':'Yerel state doğrulandı; Meta hesabı henüz bağlanmadı.'}
        assert c.post(verify,json={'state':payload['state']},headers=a).status_code==400
        assert c.post(verify,json={'state':'x'*40},headers=a).status_code==400
        assert c.get('/api/publishing/status',headers=a).json()['connected'] is False
        assert c.post('/api/members',json={'email':'editor@example.com','password':'Password2026Strong!','role':'editor'},headers=a).status_code==201
        editor={'Authorization':'Bearer '+c.post('/api/login',json={'email':'editor@example.com','password':'Password2026Strong!'}).json()['token']}
        assert c.post(url,json={'confirmation':True},headers=editor).status_code==403
        assert c.post(verify,json={'state':'x'*40},headers=editor).status_code==403
