from deployment_gate import evaluate


def test_release_gate_blocks_missing_live_services(tmp_path):
    result = evaluate({}, tmp_path)
    assert not result['ready']
    assert any(x['check'] == 'Instagram canlı yayın izni' and not x['ok'] for x in result['checks'])
    assert any(x['check'] == 'Render Blueprint' and not x['ok'] for x in result['checks'])


def test_release_gate_never_claims_meta_connected(tmp_path):
    (tmp_path / 'render.yaml').write_text('plan: starter\nmountPath: /var/data\n')
    env = {
        'SOCIALPLAN_DB':'/var/data/db.sqlite3',
        'SOCIALPLAN_MEDIA':'/var/data/media',
        'SOCIALPLAN_BACKUP_STATUS':'/var/data/backup.json',
        'SOCIALPLAN_REQUIRE_PERSISTENT':'1',
        'SOCIALPLAN_AUTO_BACKUP':'1',
        'SOCIALPLAN_BACKUP_BUCKET':'test-bucket',
        'AWS_ACCESS_KEY_ID':'fake',
        'AWS_SECRET_ACCESS_KEY':'fake',
        'SOCIALPLAN_ALERT_WEBHOOK':'https://example.com/hook',
    }
    result = evaluate(env, tmp_path)
    assert not result['ready']
    assert len([x for x in result['checks'] if not x['ok']]) == 1
