"""Real Chromium UI flow with in-memory API responses, no localhost/network access.
Run: python tests/browser_offline_ui.py
This checks frontend behavior only; it does NOT prove live backend integration.
"""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
posts=[]
state={'registered':False,'logged':False}

def respond(route):
    request=route.request
    path=request.url.split('socialplan.test',1)[-1].split('?',1)[0]
    method=request.method
    def answer(payload,status=200):
        route.fulfill(status=status,content_type='application/json; charset=utf-8',body=json.dumps(payload,ensure_ascii=False))
    if path=='/':
        return route.fulfill(status=200,content_type='text/html; charset=utf-8',body=(ROOT/'static/index.html').read_text())
    if path=='/app.js':
        return route.fulfill(status=200,content_type='text/javascript; charset=utf-8',body=(ROOT/'static/app.js').read_text())
    if path=='/manifest.webmanifest':
        return route.fulfill(status=200,content_type='application/manifest+json',body='{}')
    if path=='/icon.svg':
        return route.fulfill(status=200,content_type='image/svg+xml',body=(ROOT/'static/icon.svg').read_text())
    if path=='/api/register' and method=='POST':
        state['registered']=True;return answer({'message':'İşletme oluşturuldu.'},201)
    if path=='/api/login' and method=='POST':
        assert state['registered'];state['logged']=True;return answer({'token':'test-token'})
    if path=='/api/me':return answer({'business':'RHM Teras TEST','email':'pilot@example.com','role':'admin'})
    if path=='/api/dashboard':return answer({'draft':sum(p['status']=='draft' for p in posts),'approved':sum(p['status']=='approved' for p in posts),'cancelled':0,'members':1})
    if path=='/api/posts' and method=='POST':
        data=request.post_data_json;posts.append({'id':len(posts)+1,'caption':data['caption'],'scheduled_at':data['scheduled_at'],'status':'draft','media_id':None});return answer(posts[-1],201)
    if path=='/api/posts' and method=='GET':return answer(posts)
    if path.startswith('/api/posts/') and path.endswith('/approve'):
        post_id=int(path.split('/')[3]);posts[post_id-1]['status']='approved';return answer({'message':'ok'})
    if path=='/api/logout':state['logged']=False;return answer({'message':'ok'})
    if path=='/sw.js':return route.fulfill(status=200,content_type='text/javascript',body='')
    raise AssertionError(f'Unexpected UI request: {method} {path}')

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844},service_workers='block')
    errors=[]
    page.on('pageerror',lambda error: errors.append(str(error)))
    page.route('https://socialplan.test/**',respond)
    page.goto('https://socialplan.test/',wait_until='load')
    page.locator('#email').fill('pilot@example.com')
    page.locator('#password').fill('PilotSifre2026!!')
    page.locator('#business').fill('RHM Teras TEST')
    page.locator('#registerBtn').click()
    page.get_by_text('İşletme oluşturuldu.',exact=False).wait_for()
    page.locator('#loginBtn').click()
    page.locator('#workspace').wait_for(state='visible')
    page.locator('[data-tab="create"]').click()
    page.locator('#caption').fill('Tarayıcı testi gönderisi')
    page.locator('#scheduled').fill('2026-12-01T15:00')
    page.locator('#saveBtn').click()
    page.get_by_text('Tarayıcı testi gönderisi').wait_for()
    page.get_by_role('button',name='Onayla').click()
    page.get_by_text('Onaylı').wait_for()
    page.locator('#logoutBtn').click()
    page.locator('#auth').wait_for(state='visible')
    assert not errors,errors
    assert posts[0]['status']=='approved'
    browser.close()
print('PASS: Chromium mobile UI: register, login, create, approve, logout; no JavaScript page errors (mock API)')
