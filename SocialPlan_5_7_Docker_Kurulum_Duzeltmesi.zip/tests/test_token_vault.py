import os
import sqlite3
import pytest
from cryptography.fernet import Fernet
from token_vault import setup_vault, save_token, load_token, delete_token, cipher_from_environment

@pytest.fixture
def vault(monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_TOKEN_KEY', Fernet.generate_key().decode())
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE businesses(id INTEGER PRIMARY KEY)')
    db.executemany('INSERT INTO businesses(id) VALUES (?)', [(1,), (2,)])
    setup_vault(db)
    yield db
    db.close()

def test_encryption_and_tenant_isolation(vault):
    save_token(vault,1,'instagram','IG_SECRET_1')
    assert load_token(vault,1,'instagram')=='IG_SECRET_1'
    assert load_token(vault,2,'instagram') is None
    raw=vault.execute('SELECT encrypted_token FROM integration_credentials').fetchone()[0]
    assert b'IG_SECRET_1' not in raw
    save_token(vault,2,'instagram','IG_SECRET_2')
    assert load_token(vault,2,'instagram')=='IG_SECRET_2'
    assert delete_token(vault,1,'instagram')==1
    assert load_token(vault,1,'instagram') is None
    assert load_token(vault,2,'instagram')=='IG_SECRET_2'

def test_tamper_detection(vault):
    save_token(vault,1,'instagram','secret')
    vault.execute('UPDATE integration_credentials SET encrypted_token=? WHERE business_id=1', (b'corrupted',))
    with pytest.raises(RuntimeError,match='çözülemedi'):
        load_token(vault,1,'instagram')

def test_missing_and_wrong_key(vault,monkeypatch):
    save_token(vault,1,'instagram','secret')
    monkeypatch.delenv('SOCIALPLAN_TOKEN_KEY')
    with pytest.raises(RuntimeError,match='eksik'):
        load_token(vault,1,'instagram')
    monkeypatch.setenv('SOCIALPLAN_TOKEN_KEY',Fernet.generate_key().decode())
    with pytest.raises(RuntimeError,match='çözülemedi'):
        load_token(vault,1,'instagram')

def test_reject_unsupported_provider(vault):
    with pytest.raises(ValueError):
        save_token(vault,1,'other','secret')
