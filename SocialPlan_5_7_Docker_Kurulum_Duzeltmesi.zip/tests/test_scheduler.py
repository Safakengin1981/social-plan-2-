import json
from datetime import datetime
from zoneinfo import ZoneInfo
import scheduler

TZ = ZoneInfo('Europe/Istanbul')

def test_daily_time_and_success():
    before = datetime(2026, 11, 1, 23, 29, tzinfo=TZ)
    after = datetime(2026, 11, 1, 23, 30, tzinfo=TZ)
    assert not scheduler.due(before)
    assert scheduler.due(after)
    assert not scheduler.due(after, {'status':'success', 'time_utc':'2026-11-01T20:30:00+00:00'})
    assert scheduler.due(datetime(2026, 11, 2, 23, 30, tzinfo=TZ), {'status':'success','time_utc':'2026-11-01T20:30:00+00:00'})

def test_retry_delay():
    status = {'status':'failure','time_utc':'2026-11-01T20:30:00+00:00'}
    assert not scheduler.due(datetime(2026,11,1,23,59,tzinfo=TZ),status)
    assert scheduler.due(datetime(2026,11,2,0,31,tzinfo=TZ),status)

def test_tick_and_no_duplicate(monkeypatch,tmp_path):
    path = tmp_path/'status.json'
    monkeypatch.setenv('SOCIALPLAN_BACKUP_STATUS',str(path))
    calls=[]
    def runner(status_file):
        calls.append(True)
        status={'status':'success','time_utc':'2026-11-01T20:30:00+00:00','verified':True}
        status_file.write_text(json.dumps(status))
        return status
    now=datetime(2026,11,1,23,31,tzinfo=TZ)
    assert scheduler.tick(now,runner)=='success'
    assert scheduler.tick(now,runner)=='not_due'
    assert len(calls)==1
