import os
import subprocess
import sys
from pathlib import Path


def test_interrupted_endpoint_is_tenant_scoped_and_read_only(tmp_path):
    root = Path(__file__).resolve().parents[1]
    script = r'''
from fastapi.testclient import TestClient
from app import app, db
client = TestClient(app)
def create(name, email):
    r=client.post('/api/register',json={'business':name,'email':email,'password':'strongpassword123'})
    assert r.status_code in (200,201),r.text
    data=r.json()
    token=data.get('token')
    if not token:
        login=client.post('/api/login',json={'email':email,'password':'strongpassword123'})
        assert login.status_code==200,login.text
        token=login.json()['token']
    return {'Authorization':'Bearer '+token}
a=create('AA','a@example.com')
b=create('BB','b@example.com')
with db() as c:
    a_id=c.execute("SELECT id FROM businesses WHERE name='AA'").fetchone()['id']
    b_id=c.execute("SELECT id FROM businesses WHERE name='BB'").fetchone()['id']
    for business_id in (a_id,b_id):
        user=c.execute('SELECT id FROM users WHERE business_id=?',(business_id,)).fetchone()['id']
        p=c.execute("INSERT INTO posts(business_id,creator_id,caption,scheduled_at,status,created_at) VALUES(?,?,?,'2026-12-01T12:00:00+00:00','approved','2026-11-01T12:00:00+00:00')",(business_id,user,'test')).lastrowid
        c.execute("INSERT INTO publish_jobs(business_id,post_id,status,created_at,updated_at) VALUES(?,?,'uncertain','2026-11-01','2026-11-01')",(business_id,p))
r=client.get('/api/admin/publishing-jobs/interrupted',headers=a)
assert r.status_code==200,r.text
assert r.json()['count']==1,r.text
assert r.json()['jobs'][0]['auto_retry_allowed'] is False
assert r.json()['meta_verified'] is False
assert client.get('/api/admin/publishing-jobs/interrupted').status_code==401
with db() as c:
    assert c.execute("SELECT COUNT(*) AS n FROM publish_jobs WHERE status='uncertain'").fetchone()['n']==2
print('ok')
'''
    env = os.environ.copy()
    env['SOCIALPLAN_DB'] = str(tmp_path / 'test.sqlite3')
    env['SOCIALPLAN_MEDIA'] = str(tmp_path / 'media')
    env.pop('SOCIALPLAN_REQUIRE_PERSISTENT', None)
    result = subprocess.run([sys.executable, '-c', script], cwd=root, env=env, capture_output=True, text=True, timeout=45)
    assert result.returncode == 0, result.stdout + '\n' + result.stderr
