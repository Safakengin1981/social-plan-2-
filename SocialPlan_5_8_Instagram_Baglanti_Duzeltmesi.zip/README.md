# SocialPlan 2.9 — Yedek durum izlemesi ve başarısızlık uyarısı

Bu paket önceki 2.8 sürümünün uygulama özelliklerini korur.

## Yeni
- `backup_job.py` başarısız yedekleme durumunu dosyaya kaydeder ve `SOCIALPLAN_ALERT_WEBHOOK` tanımlıysa HTTPS webhook'a genel bir hata bildirimi gönderir. URL ve hata ayrıntıları bildirime eklenmez.
- Yönetici oturumuyla `GET /api/admin/backup-status` son yedeğin doğrulanıp doğrulanmadığını ve 26 saatten eski olup olmadığını gösterir. Editörler bu endpoint'e erişemez.
- `SOCIALPLAN_BACKUP_STATUS` dosyasını **kalıcı disk** üzerinde tutun (örnek `/var/data/backup-status.json`).
- `SOCIALPLAN_ALERT_WEBHOOK` güvenli, erişim kontrollü bir bildirim alıcısı gerektirir; tanımlanmazsa bildirim gönderilmez.

## Kritik sınırlar
- **Zamanlayıcı kurulmuş değildir.** Render Cron veya başka bir scheduler ile `python backup_job.py` günlük çalıştırılmalıdır. Cron ve web servisi aynı dosya sistemini paylaşmayabilir; bu durumda durum dosyasının aktarılması için ayrı bir kalıcı kanal gerekir.
- Harici S3 depolama hesabı, Render kalıcı disk, canlı dağıtım ve gerçek webhook henüz doğrulanmadı.
- `render.yaml` ücretli disk gerektirir; ücretsiz geçici depolama canlı veri için uygun değildir.
- Tarayıcı uçtan uca testinin gerçek tarayıcıda başarıyla çalıştığı doğrulanmadı.
- Instagram otomatik paylaşım ve Meta yetkilendirmesi henüz uygulanmadı.

## Yerel test
`pip install -r requirements.txt -r requirements-test.txt` ve `pytest -q`.

## SocialPlan 3.0 — Dahili günlük zamanlayıcı
- `SOCIALPLAN_AUTO_BACKUP=1` olduğunda web sunucusu açılışında günlük yedekleme kontrolü başlar.
- İstanbul saatine göre 23:30'da S3 yedeği oluşturulur ve geri indirilerek doğrulanır.
- Başarısızlıkta yaklaşık 1 saat sonra tekrar denenir; kontrol döngüsü 5 dakikada bir çalışır. Sunucu kapalıysa görev çalışmaz; gece geç açılışta sınırlı telafi vardır.
- Aynı kalıcı diski paylaşan işlemler arasında `flock` kilidi kullanılır. Tek worker önerilir. Birden fazla bağımsız sunucu/kalıcı disk için dağıtık kilit sağlamaz.
- `SOCIALPLAN_BACKUP_STATUS=/var/data/backup-status.json` kalıcı diskte tutulmalıdır.
- S3 hesabı ve `SOCIALPLAN_BACKUP_BUCKET`, AWS kimlik bilgileri (ve S3 uyumlu servis kullanılıyorsa `SOCIALPLAN_S3_ENDPOINT`) ayrıca yapılandırılmalıdır.
- `SOCIALPLAN_ALERT_WEBHOOK` isteğe bağlıdır; yapılandırılmadan gerçek bildirim gitmez.
- Render Blueprint ücretli disk gerektirir. Hiçbir canlı Render dağıtımı veya gerçek S3 testi bu paket kapsamında yapılmadı.
- Zamanlayıcı uygulama sürecine bağlıdır; yüksek güvenilirlik için bağımsız yönetilen zamanlayıcı ve harici izleme önerilir.
- Test: `pytest -q` (23 test geçti, 2026-11-01).

## SocialPlan 3.1 — Canlı kurulum ön kontrolü ve tarayıcı teşhisi
- `python preflight.py` sekiz kritik canlı yapılandırma kontrolü yapar; eksik varsa hata koduyla çıkar. Anahtarların değerlerini ekrana basmaz.
- Kontrol yalnızca ayarların **tanımlı** olduğunu doğrular; diskin gerçekten kalıcı olduğunu, S3 yetkilerini veya webhook'un mesaj teslimini kanıtlamaz.
- `tests/test_preflight.py` geçerli ve eksik yapılandırmaları test eder.
- `tests/browser_smoke.py` gerçek Chromium testini içerir. Bu çalışma ortamında Chromium bağlantıları yönetici politikasıyla engellendi (`ERR_BLOCKED_BY_ADMINISTRATOR`). `tests/browser_offline_ui.py` de aynı engelle karşılaştı. Bu nedenle gerçek tarayıcı testinin başarılı olduğu iddia edilmez.
- Canlı Render, S3 ve Instagram bağlantısı **kurulmadı**. Render'da kalıcı disk ücretli olabilir. Gerçek verileri henüz yüklemeyin.

## SocialPlan 3.2 — Yönetici ekranında yedek durumu
- Genel Bakış ekranında yalnızca yönetici için yedekleme sağlık kartı ve **Yenile** düğmesi eklendi.
- Kart, mevcut `/api/admin/backup-status` API'sinden gelen doğrulanmış/eksik/eski/başarısız durumu gösterir; yedek oluşturmaz.
- `tests/test_backup_dashboard_ui.py` temel arayüz bağlarını denetler.
- **Gerçek Chromium + gerçek API testi denenmiş ancak bu ortamda `ERR_BLOCKED_BY_ADMINISTRATOR` nedeniyle çalıştırılamamıştır.** Test betiği `tests/browser_real_api.py` içinde bırakılmıştır; başarılı olarak raporlanmaz.
- Kalıcı disk, S3 ve Render üzerinde canlı test hâlâ yapılmadı. Bu paket canlıya hazır değildir.

## SocialPlan 3.3 — CSV dışa aktarma güvenliği
- İçerik açıklamaları Excel/Sheets tarafından formül olarak çalıştırılmasın diye `=`, `+`, `-`, `@` ve bazı boşluk/kontrol karakteriyle başlayan alanlar CSV çıktısında tek tırnakla güvenli hale getirilir.
- Bu koruma yalnızca dışa aktarmada uygulanır; veritabanındaki özgün içerik değiştirilmez.
- Çoklu işletme izolasyonu ve yetkisiz CSV erişimi ayrıca test edilir.
- Bu sürüm canlı Render/S3 kurulumunu **yapmaz**. Chromium uçtan uca testi mevcut ortamda `ERR_BLOCKED_BY_ADMINISTRATOR` nedeniyle tamamlanamamıştır.

## SocialPlan 3.4 — Medya dosyası tür doğrulaması
- JPG, PNG, WebP ve MP4 yüklemelerinde istemcinin bildirdiği MIME türüne ek olarak dosyanın ilk baytları kontrol edilir. Bildirilen türle uyuşmayan içerik 415 yanıtıyla reddedilir.
- Reddedilen içerik için medya kaydı ve diskte dosya oluşturulmaz.
- Test: `pytest -q` — 29 test başarılı (2026-11-01).
- **Sınır:** İmza kontrolü tam medya ayrıştırması, antivirüs taraması veya dosyanın güvenli olduğuna dair garanti değildir. Gerçek kullanım öncesi medya taraması, boyut/format doğrulaması ve üretim ortamı kontrolleri gereklidir.
- Gerçek Chromium testi ortam politikası nedeniyle çalıştırılamadı. Render, S3 ve Instagram canlı entegrasyonları henüz doğrulanmadı.

## SocialPlan 3.5 — Yönetici işlem geçmişi
- Taslak oluşturma, düzenleme, onaylama ve iptal işlemleri aynı veritabanı işlemi içinde `audit_events` tablosuna kaydedilir. İşlem geri alınırsa olay kaydı da geri alınır.
- Yönetici Genel Bakış ekranında **Son işlemleri göster** ile işlem zamanı, içerik numarası, işlem türü ve işlemi yapan e-postayı görebilir.
- `GET /api/admin/audit?limit=30` yalnız yöneticiye açıktır; işletmeler arası kayıtlar izole edilir.
- Bu kayıtlar silinmeye karşı değiştirilemez dış denetim günlüğü değildir; uygulama veritabanındaki operasyon geçmişidir.
- `pytest -q`: 30 test başarılı. Gerçek Chromium testi yeniden denendi fakat `ERR_BLOCKED_BY_ADMINISTRATOR` nedeniyle tamamlanamadı. Render ve S3 canlı kurulumları yapılmadı.

## 3.6 Yayın hazırlık kuyruğu
`GET /api/admin/publishing-queue` yalnız yöneticiye açıktır. Onaylanan içerikleri, planlanan saatinin gelip gelmediğini ve Instagram otomatik yayını önündeki engelleri salt okunur döndürür. Hiçbir içerik Instagram'a gönderilmez. Gerçek entegrasyon için Meta izinleri, token saklama, kamuya erişilebilir medya ve güvenilir iş kuyruğu gerekir.

## Sürüm 3.7 — Yönetici yayın kuyruğu ve Instagram hazırlık ekranı
Yayın Durumu sekmesinde yöneticiler onaylı içerikleri, yayın saatlerini ve engelleri görür.
`GET /api/admin/instagram-readiness` yalnızca ortam değişkenlerinin tanımlı olup olmadığını ve kurulum adımlarını gösterir. Gizli anahtar değerlerini döndürmez. **OAuth, Instagram hesap bağlantısı ve otomatik yayın YOKTUR.**
Gerçek hesap bağlamak için Meta geliştirici izinleri ve doğrulanmış OAuth akışı gerekir.

## SocialPlan 3.8 — Gerçek HTTP yeniden başlatma testi
- `tests/test_live_http_smoke.py`, uvicorn'u gerçek 127.0.0.1 HTTP portunda başlatır; ana sayfa ve JavaScript'i HTTP üzerinden okur, işletme açar, giriş yapar ve içerik oluşturur.
- Sunucu sürecini tamamen kapatır ve yeniden başlatır; kayıtlı kullanıcı ve içeriğin aynı disk üzerindeki SQLite veritabanında kaldığını HTTP üzerinden doğrular.
- Bu test **yerel HTTP entegrasyon testi**dir; Chromium/Android tarayıcısı veya Render bulut diski testi değildir.
- Instagram OAuth, Meta hesabı bağlantısı, otomatik yayın ve canlı bulut depolama henüz uygulanmamıştır. Gerçek işletme verileriyle kullanılmamalıdır.


## SocialPlan 3.9: Instagram OAuth state güvenlik temeli
`POST /api/admin/instagram/oauth-state` (JSON `{ "confirmation": true }`) yöneticiye 10 dakika geçerli rastgele state verir. `POST /api/admin/instagram/oauth-state/verify` (JSON `{ "state": "..." }`) yalnız aynı işletmenin aynı yöneticisinin state değerini **bir kez** doğrular. State SHA-256 özeti veritabanında saklanır; ham değer yalnız ilk yanıtta döner.

**Bu bir Instagram OAuth bağlantısı DEĞİLDİR.** Yetkilendirme URL'si, Meta callback, kod/token değişimi, şifreli token saklama ve gerçek paylaşım bilinçli olarak etkinleştirilmemiştir. Meta hesabı bağlı gösterilmez. Bu API'ler üretim kullanımına açılmadan önce OAuth akışının Meta'nın güncel dokümanlarına göre uygulanması ve gerçek hesapla test edilmesi gerekir.

## SocialPlan 4.0 — Şifreli Instagram erişim anahtarı kasası (altyapı)
- `token_vault.py` işletme bazında erişim anahtarını Fernet ile **uygulama seviyesinde şifreleyerek** veritabanına kaydetme, okuma, güncelleme ve silme fonksiyonları sunar.
- `SOCIALPLAN_TOKEN_KEY` ortam değişkeni zorunludur; anahtar olmadan kasaya kayıt/okuma yapılamaz. Anahtar uygulama dosyalarında, ZIP'te veya veritabanında saklanmaz.
- Yeni `integration_credentials` tablosu mevcut veritabanı başlatılırken oluşturulur.
- **Bu modül henüz API'ye bağlanmamıştır.** Meta OAuth kod değişimi, token yenileme, Instagram bağlantısı ve yayınlama hâlâ **yoktur**. Rastgele veya sahte tokenları gerçek Instagram hesabı bağlantısı olarak göstermeyin.
- Gerçek dağıtımda anahtarın yedeklenmesi, rotasyonu, erişim yetkileri, sağlayıcı tokenlarının süresi ve iptali ayrıca yönetilmelidir. Anahtar kaybolursa şifreli tokenlar geri çözülemez.
- Bu çalışma ortamında yalnızca yerel otomatik testler gerçekleştirilmiştir; Render/Meta üzerinde canlı doğrulama yapılmamıştır.

## SocialPlan 4.1 — Instagram izin ekranı bağlantısı (pilot)
Yönetici onaylı `POST /api/admin/instagram/authorization-url` uç noktası,
`INSTAGRAM_CLIENT_ID` (Instagram ürünü App ID) ve `INSTAGRAM_REDIRECT_URI`
(HTTPS ve Meta panelinde birebir kayıtlı) ortam değişkenleri tanımlandığında
Instagram'ın resmi izin ekranı adresini ve 10 dakikalık tek kullanımlık state'i üretir.
İzinler: `instagram_business_basic`, `instagram_business_content_publish`.
**Dikkat:** Callback, koddan token alma, token yenileme ve gerçek yayınlama
bu sürümde YOKTUR. Üretilen bağlantı henüz tamamlanmış bir hesap bağlantısı değildir.
Bu uç noktayı gerçek kullanıcılarla kullanmadan önce Meta uygulaması ve callback
akışı tamamlanmalıdır. Gerçek erişim anahtarlarını ZIP'e koymayın.

## SocialPlan 4.2 — Instagram OAuth callback (test altyapısı)
- `GET /api/instagram/callback` Meta'nın yönlendirdiği `code` ve `state` parametrelerini kabul eder. State süresi ve tek kullanımlık oluşu kontrol edilir; kod, Meta token endpoint'ine sunucu tarafında gönderilir.
- Gelen erişim anahtarı `SOCIALPLAN_TOKEN_KEY` kullanılarak şifreli kasaya kaydedilir. İşletmeye ait Instagram hesap kimliği ayrıca saklanır. Kod ve token istemciye geri gönderilmez.
- **Varsayılan olarak KAPALI:** `INSTAGRAM_OAUTH_ENABLED=1` olmadan callback 503 döndürür. `INSTAGRAM_CLIENT_ID`, `INSTAGRAM_CLIENT_SECRET`, `INSTAGRAM_REDIRECT_URI` ve `SOCIALPLAN_TOKEN_KEY` güvenli ortam değişkenleri olarak tanımlanmalıdır. Redirect URI Meta panelinde birebir aynı olmalı ve `/api/instagram/callback` yoluna gitmelidir.
- Yetkilendirme tamamlandığında kullanıcıya bağlantı ekranı gösterilir; **Instagram'da paylaşım yapılmaz**. Kısa süreli tokenın uzun süreli tokena çevrilmesi, yenilenmesi, izinlerin canlı doğrulanması, bağlantı durum ekranı ve yayın işçisi henüz yapılmadı. Dolayısıyla üretim kullanımına açmayın.
- Testte gerçek Meta ağı kullanılmaz; `exchange_code` kontrollü test cevabıyla değiştirilir. Gerçek Meta bağlantısı ve Render üzerinde canlı kurulum **test edilmedi**.
- `pytest -q`: 40 test başarılı (2026-11-01). FastAPI eski startup uyarıları devam ediyor.

## SocialPlan 4.3 — Instagram hesap yönetimi (pilot)

- `GET /api/admin/instagram/account`: yöneticiye özel bağlantı durumu; token değeri hiçbir zaman yanıtta verilmez.
- `DELETE /api/admin/instagram/account`: yalnızca ilgili işletmenin **yerel** Instagram token ve hesap kaydını kaldırır; bekleyen OAuth state kayıtlarını siler. Meta tarafındaki uygulama yetkisini geri çekmez.
- `stored_unverified`: şifreli kimlik bilgisi ve hesap kaydı var, ancak Meta API üzerinden canlı doğrulanmadı.
- `credential_unavailable`, `credential_missing`, `expired`: bağlantının kullanılamayabileceğini belirten durumlar.
- Bu sürümde otomatik token yenileme, gerçek hesap doğrulaması ve paylaşım **yoktur**. OAuth callback gerçek Meta hesabıyla sınanmamıştır.
- Yerel test: `pytest -q` (41 test). Render ve tarayıcı testleri yapılmamıştır.

## SocialPlan 4.4 — Instagram uzun süreli token yönetimi

- OAuth callback artık kısa süreli Instagram Login token'ını `ig_exchange_token` ile uzun süreli token'a dönüştürmeyi dener; dönüşüm başarısız olursa hesabı bağlı olarak kaydetmez.
- `POST /api/admin/instagram/refresh` yalnızca yönetici oturumuna açıktır ve `INSTAGRAM_OAUTH_ENABLED=1` gerektirir. Başarılı yenileme şifreli token'ı ve geçerlilik tarihini günceller.
- İlk bağlama veya yenileme sonrasında geçerlilik süresi API yanıtındaki `expires_in` değerinden hesaplanır. Henüz yenileme için yeterince eski olmayan veya süresi dolmuş token reddedilir. Bu sürüm yenilemeyi yönetici isteğiyle yapar; otomatik token yenileme zamanlayıcısı **yoktur**.
- Testler sahte Meta yanıtları kullanır. Meta hesap bağlantısı, yayınlama, gerçek Render dağıtımı ve harici yedekleme hâlâ canlı ortamda doğrulanmamıştır.
- `SOCIALPLAN_TOKEN_KEY` anahtarını kaybederseniz kayıtlı token'lar açılamaz. Anahtarın güvenli harici saklanması gereklidir.

## SocialPlan 4.5 — yayın işi hazırlama (gerçek paylaşım YOK)

Yönetici, onaylanmış ve desteklenen medya eklenmiş içerik için `POST /api/admin/publishing-queue/{post_id}/prepare` çağrısıyla bir yayın hazırlık kaydı oluşturabilir. Aynı işletme ve içerik için ikinci çağrı yeni kayıt açmaz. `GET /api/admin/publishing-jobs` yalnızca ilgili işletmenin kayıtlarını döndürür. Bu iki uç nokta Meta API'ye istek yapmaz, otomatik gönderim başlatmaz ve yayınlandı durumunu üretmez.

**Eksikler:** Meta'nın medya container oluşturma / durum kontrolü / publish akışı, kamuya açık güvenli medya URL'leri, dağıtık işçi, ağ hatalarında belirsiz sonuçların uzlaştırılması, zamanlayıcı, gerçek hesap ve canlı sunucu doğrulaması. `pending` yalnızca yerel hazırlık kaydıdır; Instagram'da yayın anlamına gelmez.

## SocialPlan 4.6 — Instagram yayın transportu (pilot)

`instagram_publish.py` modülü Instagram Graph API üzerinden fotoğraf medya konteyneri
oluşturma, konteyner durumunu sorgulama ve yayınlama isteğini içerir. **Bu modül
henüz uygulamanın otomatik iş kuyruğuna bağlanmamıştır.** Gerçek Instagram
hesabına gönderim yapılmamıştır. Video/Reels, carousel, medya URL erişimi,
izinler ve oran sınırları için ek çalışma gerekir.

Özellikle `media_publish` isteği zaman aşımına uğrarsa yanıtın kaybolması
paylaşımın yapılmadığını kanıtlamaz. Modül `PublishUncertain` üretir;
**otomatik yeniden gönderim yapılmamalıdır**. Meta üzerinden durum
uzlaştırması ve kalıcı yayın kimliği yönetimi tamamlanmadan canlıya alınmaz.

Test: `python -m pytest -q` (Meta istekleri sahte HTTP yanıtlarıyla sınanır).

## Sürüm 4.7 — Yayın işi geçmişi

`POST /api/admin/publishing-jobs/{job_id}/transition` yalnızca yöneticiye açıktır.
Durum akışı: `pending → container_created → container_ready → publishing → published`.
Bağlantı belirsizliğinde `publishing → uncertain` kullanılır. Belirsiz sonuçtan otomatik yeniden gönderim yapılmaz; yönetici ancak dışarıda doğruladığı sonuçla `publish_confirmed` veya açıklama ekleyerek `manual_cancel` kaydı yapabilir.
`GET /api/admin/publishing-jobs/{job_id}/history` işlem geçmişini döndürür. Meta kimliği ve işlem açıklaması kaydedilir. **Bu endpointler Meta API çağrısı yapmaz; yöneticinin bildirdiği sonuçlar Meta tarafından doğrulanmış kabul edilemez.** Gerçek yayın motoruna bağlanmadan önce HTTPS medya dağıtımı, güvenli worker, Meta durum mutabakatı ve entegrasyon testleri gerekir.

## SocialPlan 4.8 — yayın yürütme çekirdeği (test aşaması)

`publish_runner.py` onaylanmış, medyalı bir yayın işini Meta medya konteyneri oluşturma → hazır olma kontrolü → yayımlama aşamalarından geçirir. Kritik durumları her dış çağrıdan önce kalıcı olarak kaydeder. Yayınlama yanıtı belirsizse işi `uncertain` durumuna alır ve **otomatik yeniden denemez**. `tests/test_publish_runner.py` bu akışı sahte Meta istemcisiyle test eder.

**Güvenlik sınırı:** Bu modül bilinçli olarak uygulamanın HTTP uç noktalarına veya zamanlayıcısına bağlanmamıştır; gerçek hesapta hiçbir işlem başlatmaz. Üretim kullanımı öncesi iş kilitleme/worker koordinasyonu, yayın durumunu Meta ile uzlaştırma, erişilebilir HTTPS medya URL'si, gerçek Meta hesap bağlantısı ve kalıcı depolama doğrulaması gerekir. Ayrıca medya konteynerinin uzun süren işlenmesi için ayrı bir devam ettirme akışı henüz yoktur.

## 4.9 — Yönetici yayın işi görünümü

* **Yayın Durumu** sekmesinde onaylanmış içerikler için **Yayın işi hazırla** düğmesi eklendi. Bu düğme yalnızca hazırlık kaydı oluşturur; Meta'ya gönderim yapmaz.
* Aynı sekmede yayın işlerinin durumu, hata notları ve **İşlem geçmişi** düğmesi bulunur. Belirsiz sonuçlar açıkça işaretlenir.
* Durumlar veritabanındaki kayıtları gösterir; **Meta tarafından doğrulanmış canlı yayın kanıtı değildir**.
* Yönetici dışındaki kullanıcılar bu kayıtları göremez. Eski Render servisi değiştirilmemiştir.
* Otomatik paylaşım, gerçek Instagram yetkilendirmesi ve canlı depolama/yedekleme doğrulaması henüz tamamlanmadı.

## SocialPlan 5.0 — Yayın kimliği kalıcılığı

- `publish_jobs` tablosuna `container_id` ve `published_media_id` alanları eklendi. Mevcut veritabanlarında `setup()` sırasında sütunlar eklenir.
- `publish_runner.run_image_job` Meta konteyner kimliğini ve başarılı yayın kimliğini kaydeder.
- `inspect_interrupted_jobs` işletme bazında yarım kalmış işleri salt okunur listeler; hiçbir iş otomatik tekrar gönderilmez.
- Yeni testler Meta kimliklerinin kalıcı kaydını ve yarım kalan işlerin tekrar gönderilmemesini doğrular.

**Sınır:** Gerçek Meta hesabı ile yayınlama, canlı Render ve kalıcı depolama doğrulanmadı. Bu kod, yayın motorunun yönetici ekranından otomatik çalıştırıldığı anlamına gelmez.

## SocialPlan 5.1 — Yarım kalan yayınların salt okunur denetimi

Yönetici `GET /api/admin/publishing-jobs/interrupted` adresinden kendi işletmesine ait `creating_container`, `container_created`, `publishing`, `uncertain` durumundaki yayınları görebilir. Yanıt `auto_retry_allowed: false`, `meta_verified: false` alanlarını taşır. Bu uç nokta **Meta'ya bağlanmaz, paylaşım yapmaz, yayın durumunu değiştirmez**. İşletme ayrımı ve yetkisiz erişim otomatik testle doğrulanmıştır.

Yerel test: `pytest -q` → 57 başarılı (22 uyarı; eski FastAPI `on_event` kullanımı dahil). Canlı Render, gerçek Meta ve gerçek tarayıcı testi yapılmamıştır.


## SocialPlan 5.2 — Başlatma yaşam döngüsü
- Eski `@app.on_event('startup')` kaldırıldı; FastAPI `lifespan` kullanılıyor.
- Yedekleme zamanlayıcısı uygulama yaşam döngüsünde başlatılıyor (yalnızca `SOCIALPLAN_AUTO_BACKUP=1` ise iş yapar).
- `/api/health` sürümü 5.2 olarak güncellendi.
- Bu değişiklik canlı sunucu veya Instagram yayını doğrulaması anlamına gelmez.


## 5.3 — Medya URL koruması
Instagram yayın motoruna verilen medya URL'leri için localhost, yerel/test alan adları, doğrudan IPv4/IPv6 adresleri, özel port ve HTTP engellenir. Bu **tam SSRF koruması değildir**: DNS çözümlemesi, DNS rebinding ve Meta tarafında URL'nin çekilmesi ayrıca değerlendirilmelidir. Yayın motoru otomatik etkin değildir.

## SocialPlan 5.4 — Dağıtım güvenliği

Kurulum ZIP dosyası **veritabanı, medya dosyası, `.env`, özel anahtar veya önbellek** içermez. `data/` klasörü uygulama ilk çalıştırıldığında kendi ortamında oluşturulur. Bu sürüm **önceki gerçek verileri taşımaz**; mevcut bir kurulumun verisini korumak için doğrulanmış yedek ve kontrollü geçiş planı gerekir.

Dağıtım kontrolü: `python release_check.py SocialPlan_5_4_Temiz_Dagitim.zip`.

**Canlı kullanım uyarısı:** Render kalıcı disk, harici S3 yedekleme, gerçek Meta yetkilendirmesi, Instagram yayınlama ve tarayıcı uçtan uca testleri bu paketle canlı ortamda doğrulanmış değildir. Eski Render servisini otomatik olarak değiştirmeyin.

## SocialPlan 5.5 — Dağıtım kontrol kapısı

- `deployment_gate.py` yapılandırma eksiklerini **salt okunur** denetler. Meta canlı bağlantısı doğrulanmadığı için dağıtıma hazır (`ready=true`) sonucu **vermez**; bu bilinçli güvenlik kararıdır.
- `.github/workflows/tests.yml` kod GitHub'a yüklendiğinde ve PR açıldığında Python testlerini otomatik çalıştırır. Bu iş akışı kendi başına Render'a dağıtım yapmaz.
- `python deployment_gate.py` çalıştırılabilir; eksikler varsa çıkış kodu 1 olur. Gizli anahtar değerleri yazdırılmaz.
- `tests/test_deployment_gate.py` kontrolün eksik yapılandırmayı reddettiğini doğrular.

**Canlıya alma için hâlâ gerekli:** Render kalıcı disk bağlantısı ve gerçek yeniden başlatma testi, S3 yükleme/geri yükleme, Meta OAuth hesabı ve Instagram yayın testleri. Hiçbiri bu sürümde gerçekleştirilmiş değildir.

## SocialPlan 5.6 — Canlı kurulum için salt okunur HTTP doğrulama
- `python live_probe.py https://YENI-SERVIS.onrender.com` komutu yalnızca dört adet **GET** isteği yapar: `/api/health`, `/api/ready`, `/`, `/app.js`.
- Kullanıcı oluşturmaz, giriş yapmaz, veritabanını değiştirmez ve Instagram'a paylaşım yapmaz.
- Kontrolün başarılı olması gerçek disk kalıcılığını, yedeklemeyi veya tarayıcıda çalışmayı **kanıtlamaz**. Bunlar ayrıca doğrulanmalıdır.
- Yalnızca yerel geliştirme için `--allow-local-http` ile `http://127.0.0.1:PORT` kullanılabilir.
- Gerçek Render servisi bu paketi hazırlarken değiştirilmedi veya dağıtılmadı. `render.yaml` ücretli kalıcı disk içerir; kullanmadan önce maliyeti onaylayın.
- 5.6 sürümü canlı doğrulama aracını ve testlerini ekler; Instagram otomatik paylaşımı henüz üretimde etkin değildir.

## 5.7 — Docker canlı kurulum düzeltmesi

5.6 Dockerfile dosyası `token_vault.py`, `instagram_oauth.py`, `scheduler.py` gibi
uygulamanın çalışma zamanında ihtiyaç duyduğu modülleri kopyalamıyordu.
5.7 bunları Docker imajına dahil eder ve yeni testlerle eksik modül
kopyalanmasını kontrol eder. `.dockerignore` geliştirme verilerini ve
hassas dosyaları Docker build bağlamından dışlar.

**Bu bir dağıtım değildir.** Render servisi, Meta bağlantısı ve harici yedekleme
henüz canlı ortamda doğrulanmamıştır. Eski servisi değiştirmeyin.

## SocialPlan 5.8 — Yeniden başlatma testi ve sürüm tutarlılığı
- API sürüm alanları 5.8 olarak eşitlendi.
- `tests/test_restart_persistence.py` iki ayrı Python süreci kullanarak aynı SQLite dosyasındaki örnek kaydın süreçler arasında korunduğunu doğrular.
- Bu **yerel süreç yeniden başlatma testidir**; Render disk bağlama, sunucu yeniden dağıtımı, dış yedekleme veya Meta hesabı için canlı doğrulama değildir.
- Render entegrasyonu bağlı olmadığından canlı serviste değişiklik yapılmadı. Ücretli servis oluşturulmadı.
