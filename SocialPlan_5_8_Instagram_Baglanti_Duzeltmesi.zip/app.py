import json, os, sqlite3, secrets, hashlib, hmac, re, csv, io, uuid, shutil
from pathlib import Path
from urllib.parse import urlencode, urlparse
from datetime import datetime, timezone, timedelta
from contextlib import contextmanager, asynccontextmanager
from fastapi import FastAPI, HTTPException, Header, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field
from token_vault import setup_vault, save_token, delete_token, load_token
from instagram_oauth import exchange_code, exchange_long_lived_token, refresh_long_lived_token

ROOT=Path(__file__).resolve().parent
DB=Path(os.environ.get('SOCIALPLAN_DB', str(ROOT/'data'/'socialplan.sqlite3')))
# Fail closed when production expects a mounted persistent volume.
# /var/data is the designated Render disk mount; check mountpoint via /proc/mounts.
def require_persistent_storage():
    if os.environ.get('SOCIALPLAN_REQUIRE_PERSISTENT') != '1':
        return
    mount = Path('/var/data')
    if not DB.is_relative_to(mount):
        raise RuntimeError('Kalıcı veri modu: SOCIALPLAN_DB /var/data altında olmalı')
    if not Path(os.environ.get('SOCIALPLAN_MEDIA', '/var/data/media')).is_relative_to(mount):
        raise RuntimeError('Kalıcı veri modu: SOCIALPLAN_MEDIA /var/data altında olmalı')
    mounts = Path('/proc/mounts').read_text().splitlines()
    if not any(line.split()[1] == '/var/data' for line in mounts if len(line.split()) >= 2):
        raise RuntimeError('Kalıcı disk /var/data konumunda bağlı değil; başlatma durduruldu')

require_persistent_storage()
DB.parent.mkdir(parents=True,exist_ok=True)
@asynccontextmanager
async def lifespan(application):
    from scheduler import start
    start()
    yield

app=FastAPI(title='SocialPlan',version='5.8',docs_url=None,redoc_url=None,lifespan=lifespan)
MEDIA=Path(os.environ.get('SOCIALPLAN_MEDIA',str(DB.parent/'media')))
MEDIA.mkdir(parents=True,exist_ok=True)
MAX_UPLOAD=25*1024*1024

@contextmanager
def db():
    c=sqlite3.connect(DB,timeout=15)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    try:
        yield c
        c.commit()
    except:
        c.rollback(); raise
    finally: c.close()

def setup():
    with db() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS businesses(id INTEGER PRIMARY KEY,name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,business_id INTEGER NOT NULL,email TEXT NOT NULL UNIQUE,salt TEXT NOT NULL,hash TEXT NOT NULL,role TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
        CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,expires TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY,business_id INTEGER NOT NULL,creator_id INTEGER NOT NULL,caption TEXT NOT NULL,scheduled_at TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft',created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
        CREATE TABLE IF NOT EXISTS media(id INTEGER PRIMARY KEY,business_id INTEGER NOT NULL,filename TEXT NOT NULL,mime TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));''')
        setup_vault(c)
        c.execute('''CREATE TABLE IF NOT EXISTS oauth_states(state_hash TEXT PRIMARY KEY, business_id INTEGER NOT NULL, user_id INTEGER NOT NULL, expires TEXT NOT NULL, consumed INTEGER NOT NULL DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS instagram_accounts(business_id INTEGER PRIMARY KEY, instagram_user_id TEXT NOT NULL, connected_at TEXT NOT NULL, expires_at TEXT)''')
        account_cols={r['name'] for r in c.execute('PRAGMA table_info(instagram_accounts)')}
        if 'expires_at' not in account_cols:
            c.execute('ALTER TABLE instagram_accounts ADD COLUMN expires_at TEXT')
        c.execute('''CREATE TABLE IF NOT EXISTS publish_jobs(id INTEGER PRIMARY KEY, business_id INTEGER NOT NULL, post_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_error TEXT, UNIQUE(business_id,post_id), FOREIGN KEY(post_id) REFERENCES posts(id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS publish_job_events(id INTEGER PRIMARY KEY,job_id INTEGER NOT NULL,business_id INTEGER NOT NULL,actor_id INTEGER NOT NULL,event TEXT NOT NULL,meta_id TEXT,note TEXT,created_at TEXT NOT NULL)''')
        c.execute('CREATE TABLE IF NOT EXISTS audit_events(id INTEGER PRIMARY KEY,business_id INTEGER NOT NULL,actor_id INTEGER NOT NULL,action TEXT NOT NULL,post_id INTEGER,created_at TEXT NOT NULL)')
        columns={r['name'] for r in c.execute('PRAGMA table_info(posts)')}
        if 'media_id' not in columns:c.execute('ALTER TABLE posts ADD COLUMN media_id INTEGER REFERENCES media(id)')
        job_columns={r['name'] for r in c.execute('PRAGMA table_info(publish_jobs)')}
        for column in ('container_id','published_media_id'):
            if column not in job_columns:c.execute(f'ALTER TABLE publish_jobs ADD COLUMN {column} TEXT')
setup()

def record_audit(c,u,action,pid):
    c.execute('INSERT INTO audit_events(business_id,actor_id,action,post_id,created_at) VALUES (?,?,?,?,?)',(u['business_id'],u['id'],action,pid,datetime.now(timezone.utc).isoformat()))

def password_hash(p,s): return hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(s),260000).hex()
def check_email(e):
    e=e.strip().lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',e): raise HTTPException(422,'Geçerli e-posta girin')
    return e

def password_valid(p):
    if len(p)<12: raise HTTPException(422,'Şifre en az 12 karakter olmalı')

def current(authorization):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Oturum açın')
    th=hashlib.sha256(authorization[7:].encode()).hexdigest()
    with db() as c:
        row=c.execute('''SELECT u.id,u.business_id,u.email,u.role,b.name business FROM sessions s JOIN users u ON s.user_id=u.id JOIN businesses b ON b.id=u.business_id WHERE s.token_hash=? AND s.expires>?''',(th,datetime.now(timezone.utc).isoformat())).fetchone()
    if not row: raise HTTPException(401,'Oturum geçersiz veya süresi dolmuş')
    return dict(row)

class Register(BaseModel):
    business:str=Field(min_length=2,max_length=120)
    email:str
    password:str
class Login(BaseModel):
    email:str
    password:str
class Post(BaseModel):
    caption:str=Field(min_length=1,max_length=2200)
    scheduled_at:datetime
    media_id:int|None=None
class EditPost(BaseModel):
    caption:str=Field(min_length=1,max_length=2200)
    scheduled_at:datetime
class Member(BaseModel):
    email:str
    password:str
    role:str

@app.get('/api/health')
def health(): return {'status':'ok','version':'5.8'}
@app.get('/api/ready')
def ready():
    try:
        with db() as c:
            c.execute('SELECT 1').fetchone()
        if not MEDIA.is_dir():
            raise OSError('Medya dizini bulunamadı')
        return {'status': 'ready', 'database': 'reachable', 'media': 'reachable'}
    except Exception:
        raise HTTPException(503, 'Depolama hazır değil')

@app.get('/api/admin/backup-status')
def backup_status(authorization:str|None=Header(default=None)):
    user=current(authorization)
    if user['role'] != 'admin':
        raise HTTPException(403,'Yalnızca yöneticiler erişebilir')
    path=Path(os.environ.get('SOCIALPLAN_BACKUP_STATUS', '/tmp/socialplan-backup-status.json'))
    if not path.is_file():
        return {'status':'missing','healthy':False,'message':'Henüz yedekleme durumu kaydedilmedi'}
    try:
        record=json.loads(path.read_text(encoding='utf-8'))
        checked=datetime.fromisoformat(record['time_utc'])
        if checked.tzinfo is None:
            raise ValueError('Saat dilimi eksik')
        age_hours=(datetime.now(timezone.utc)-checked).total_seconds()/3600
        healthy=record.get('status')=='success' and record.get('verified') is True and 0<=age_hours<=26
        return {'status':record.get('status','unknown'), 'healthy':healthy,
                'time_utc':record['time_utc'], 'age_hours':round(age_hours,2),
                'verified':record.get('verified',False),
                'message':'Son yedek doğrulandı' if healthy else 'Yedek başarısız, eski veya doğrulanmamış'}
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError):
        return {'status':'invalid','healthy':False,'message':'Yedekleme durum dosyası okunamadı'}

@app.post('/api/register',status_code=201)
def register(x:Register):
    email=check_email(x.email);password_valid(x.password)
    salt=secrets.token_hex(16)
    with db() as c:
        if c.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone(): raise HTTPException(409,'Bu e-posta zaten kayıtlı')
        try:
            cur=c.execute('INSERT INTO businesses(name) VALUES (?)',(x.business.strip(),))
            c.execute('INSERT INTO users(business_id,email,salt,hash,role) VALUES (?,?,?,?,?)',(cur.lastrowid,email,salt,password_hash(x.password,salt),'admin'))
        except sqlite3.IntegrityError: raise HTTPException(409,'Bu e-posta zaten kayıtlı')
    return {'message':'İşletme oluşturuldu. Giriş yapabilirsiniz.'}
@app.post('/api/login')
def login(x:Login):
    email=check_email(x.email)
    with db() as c:
        u=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
        if not u or not hmac.compare_digest(password_hash(x.password,u['salt']),u['hash']): raise HTTPException(401,'E-posta veya şifre hatalı')
        token=secrets.token_urlsafe(40)
        c.execute('INSERT INTO sessions VALUES (?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u['id'],(datetime.now(timezone.utc)+timedelta(hours=12)).isoformat()))
    return {'token':token}
@app.get('/api/me')
def me(authorization:str|None=Header(default=None)): return current(authorization)
@app.post('/api/logout')
def logout(authorization:str|None=Header(default=None)):
    current(authorization)
    with db() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(authorization[7:].encode()).hexdigest(),))
    return {'message':'Çıkış yapıldı'}
@app.get('/api/posts')
def posts(authorization:str|None=Header(default=None)):
    u=current(authorization)
    with db() as c:return [dict(r) for r in c.execute('SELECT id,caption,scheduled_at,status,created_at,media_id FROM posts WHERE business_id=? ORDER BY scheduled_at',(u['business_id'],)).fetchall()]
@app.post('/api/posts',status_code=201)
def add_post(x:Post,authorization:str|None=Header(default=None)):
    u=current(authorization)
    if x.scheduled_at.tzinfo is None:raise HTTPException(422,'Saat dilimi gerekli')
    if x.scheduled_at.astimezone(timezone.utc)<=datetime.now(timezone.utc):raise HTTPException(422,'Gelecek bir tarih seçin')
    with db() as c:
        if x.media_id is not None and not c.execute('SELECT 1 FROM media WHERE id=? AND business_id=?',(x.media_id,u['business_id'])).fetchone():raise HTTPException(404,'Medya bulunamadı')
        cur=c.execute('INSERT INTO posts(business_id,creator_id,caption,scheduled_at,created_at,media_id) VALUES (?,?,?,?,?,?)',(u['business_id'],u['id'],x.caption,x.scheduled_at.isoformat(),datetime.now(timezone.utc).isoformat(),x.media_id))
        record_audit(c,u,'post_created',cur.lastrowid)
        return {'id':cur.lastrowid,'status':'draft'}
@app.post('/api/posts/{post_id}/approve')
def approve(post_id:int,authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':raise HTTPException(403,'Yalnız yönetici onaylayabilir')
    with db() as c:
        r=c.execute("UPDATE posts SET status='approved' WHERE id=? AND business_id=? AND status='draft'",(post_id,u['business_id']))
        if r.rowcount==0:raise HTTPException(404,'Onaylanabilir taslak bulunamadı')
        record_audit(c,u,'post_approved',post_id)
    return {'status':'approved','published':False}
@app.post('/api/posts/{post_id}/cancel')
def cancel(post_id:int,authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':raise HTTPException(403,'Yalnız yönetici iptal edebilir')
    with db() as c:
        r=c.execute("UPDATE posts SET status='cancelled' WHERE id=? AND business_id=? AND status!='cancelled'",(post_id,u['business_id']))
        if r.rowcount==0:raise HTTPException(404,'İçerik bulunamadı')
        record_audit(c,u,'post_cancelled',post_id)
    return {'status':'cancelled'}
@app.get('/api/members')
def members(authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':raise HTTPException(403,'Yetki yok')
    with db() as c:return [dict(r) for r in c.execute('SELECT email,role FROM users WHERE business_id=?',(u['business_id'],))]
@app.post('/api/members',status_code=201)
def add_member(x:Member,authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':raise HTTPException(403,'Yetki yok')
    if x.role not in ('admin','editor'):raise HTTPException(422,'Geçersiz rol')
    email=check_email(x.email);password_valid(x.password);salt=secrets.token_hex(16)
    with db() as c:
        try:c.execute('INSERT INTO users(business_id,email,salt,hash,role) VALUES (?,?,?,?,?)',(u['business_id'],email,salt,password_hash(x.password,salt),x.role))
        except sqlite3.IntegrityError:raise HTTPException(409,'Bu e-posta zaten kayıtlı')
    return {'message':'Üye eklendi'}
@app.get('/')
def home():return FileResponse(ROOT/'static'/'index.html',headers={'Cache-Control':'no-store'})
@app.get('/app.js')
def js():return FileResponse(ROOT/'static'/'app.js',media_type='application/javascript',headers={'Cache-Control':'no-store'})


@app.put('/api/posts/{post_id}')
def edit_post(post_id:int,x:EditPost,authorization:str|None=Header(default=None)):
    u=current(authorization)
    if x.scheduled_at.tzinfo is None or x.scheduled_at.astimezone(timezone.utc)<=datetime.now(timezone.utc):raise HTTPException(422,'Gelecek bir tarih seçin')
    with db() as c:
        r=c.execute("UPDATE posts SET caption=?,scheduled_at=?,status='draft' WHERE id=? AND business_id=? AND status='draft' AND (creator_id=? OR ?='admin')",(x.caption,x.scheduled_at.isoformat(),post_id,u['business_id'],u['id'],u['role']))
        if not r.rowcount:raise HTTPException(404,'Düzenlenebilir taslak bulunamadı')
        record_audit(c,u,'post_edited',post_id)
    return {'message':'Taslak güncellendi'}

@app.get('/api/admin/audit')
def audit_events(authorization:str|None=Header(default=None), limit:int=50):
    u=current(authorization)
    if u['role']!='admin':raise HTTPException(403,'Yalnızca yönetici işlem geçmişini görebilir')
    if not 1<=limit<=200:raise HTTPException(422,'Limit 1-200 arasında olmalı')
    with db() as c:
        return [dict(r) for r in c.execute('SELECT a.id,a.action,a.post_id,a.created_at,u.email AS actor FROM audit_events a JOIN users u ON u.id=a.actor_id WHERE a.business_id=? ORDER BY a.id DESC LIMIT ?',(u['business_id'],limit)).fetchall()]

@app.get('/api/dashboard')
def dashboard(authorization:str|None=Header(default=None)):
    u=current(authorization)
    with db() as c:
        counts={r['status']:r['n'] for r in c.execute('SELECT status,COUNT(*) n FROM posts WHERE business_id=? GROUP BY status',(u['business_id'],))}
        members=c.execute('SELECT COUNT(*) FROM users WHERE business_id=?',(u['business_id'],)).fetchone()[0]
    return {'draft':counts.get('draft',0),'approved':counts.get('approved',0),'cancelled':counts.get('cancelled',0),'members':members,'instagram_connected':False,'auto_publish_enabled':False}

def valid_media_signature(mime: str, header: bytes) -> bool:
    """Reject files whose bytes do not match the declared media type."""
    if mime == 'image/jpeg':
        return header.startswith(b'\xff\xd8\xff')
    if mime == 'image/png':
        return header.startswith(b'\x89PNG\r\n\x1a\n')
    if mime == 'image/webp':
        return len(header) >= 12 and header[:4] == b'RIFF' and header[8:12] == b'WEBP'
    if mime == 'video/mp4':
        return len(header) >= 12 and header[4:8] == b'ftyp' and header[8:12] in {
            b'isom', b'iso2', b'iso3', b'iso4', b'iso5', b'iso6',
            b'mp41', b'mp42', b'avc1', b'M4V ', b'M4A ', b'qt  ', b'dash', b'3gp4', b'3gp5'
        }
    return False

@app.post('/api/media',status_code=201)
async def upload_media(file:UploadFile=File(...),authorization:str|None=Header(default=None)):
    u=current(authorization)
    allowed={'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','video/mp4':'.mp4'}
    if file.content_type not in allowed:raise HTTPException(415,'Yalnız JPG, PNG, WebP veya MP4 yüklenebilir')
    header=await file.read(32)
    if not valid_media_signature(file.content_type,header):
        await file.close()
        raise HTTPException(415,'Dosya içeriği bildirilen medya türüyle uyuşmuyor')
    await file.seek(0)
    name=uuid.uuid4().hex+allowed[file.content_type]
    directory=MEDIA/str(u['business_id']);directory.mkdir(parents=True,exist_ok=True)
    target=directory/name
    size=0
    try:
        with target.open('wb') as out:
            while chunk:=await file.read(1024*1024):
                size+=len(chunk)
                if size>MAX_UPLOAD:raise HTTPException(413,'Dosya 25 MB sınırını aşıyor')
                out.write(chunk)
        if not size:raise HTTPException(422,'Boş dosya yüklenemez')
        with db() as c:
            mid=c.execute('INSERT INTO media(business_id,filename,mime,created_at) VALUES (?,?,?,?)',(u['business_id'],name,file.content_type,datetime.now(timezone.utc).isoformat())).lastrowid
        return {'id':mid,'size':size,'url':f'/api/media/{mid}'}
    except BaseException:
        target.unlink(missing_ok=True)
        raise
    finally:await file.close()

@app.get('/api/media/{media_id}')
def get_media(media_id:int,authorization:str|None=Header(default=None)):
    u=current(authorization)
    with db() as c:r=c.execute('SELECT filename,mime FROM media WHERE id=? AND business_id=?',(media_id,u['business_id'])).fetchone()
    if not r:raise HTTPException(404,'Medya bulunamadı')
    path=MEDIA/str(u['business_id'])/r['filename']
    if not path.is_file():raise HTTPException(404,'Dosya depoda bulunamadı')
    return FileResponse(path,media_type=r['mime'],headers={'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'})

@app.get('/api/posts/export.csv')
def export_csv(authorization:str|None=Header(default=None)):
    u=current(authorization)
    with db() as c:rows=c.execute('SELECT id,caption,scheduled_at,status,created_at FROM posts WHERE business_id=? ORDER BY scheduled_at',(u['business_id'],)).fetchall()
    # Spreadsheet formula injection protection: neutralize formula-like text cells.
    # Also cover leading whitespace and control characters used to bypass naive filters.
    def safe_csv_cell(value):
        if not isinstance(value, str):
            return value
        if value.lstrip(' \t\r\n').startswith(('=', '+', '-', '@')) or value.startswith(('\t', '\r', '\n')):
            return "'" + value
        return value
    f=io.StringIO();f.write('\ufeff');w=csv.writer(f);w.writerow(['ID','Açıklama','Planlanan tarih','Durum','Oluşturulma']);w.writerows(tuple(safe_csv_cell(v) for v in r) for r in rows)
    return StreamingResponse(iter([f.getvalue().encode('utf-8')]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="socialplan_icerikler.csv"','Cache-Control':'no-store'})

def instagram_stored_status(business_id):
    """Local credential state only; never implies a successful live Meta API probe."""
    with db() as c:
        row=c.execute('SELECT instagram_user_id,connected_at,expires_at FROM instagram_accounts WHERE business_id=?',(business_id,)).fetchone()
        if row is None:
            return {'connected':False,'status':'not_connected','auto_publish':False}
        try:
            has_token=bool(load_token(c,business_id,'instagram'))
        except RuntimeError:
            return {'connected':False,'status':'credential_unavailable','auto_publish':False}
        if not has_token:
            return {'connected':False,'status':'credential_missing','auto_publish':False}
        expires=row['expires_at']
        try:
            if expires and datetime.fromisoformat(expires) <= datetime.now(timezone.utc):
                return {'connected':False,'status':'expired','auto_publish':False,'expires_at':expires}
        except ValueError:
            return {'connected':False,'status':'invalid_expiry','auto_publish':False}
        return {'connected':True,'status':'stored_unverified','instagram_user_id':row['instagram_user_id'],
                'connected_at':row['connected_at'],'expires_at':expires,'auto_publish':False,
                'message':'Erişim anahtarı kayıtlı; Meta API ile canlı doğrulama yapılmadı.'}

@app.get('/api/publishing/status')
def publishing_status(authorization:str|None=Header(default=None)):
    u=current(authorization)
    account=instagram_stored_status(u['business_id'])
    return {'connected':account['connected'],'status':account['status'],'auto_publish':False,
            'message':('Instagram erişim anahtarı kayıtlı ancak canlı doğrulanmadı. Otomatik yayın kapalı.'
                       if account['connected'] else 'Instagram hesabı henüz bağlanmadı. Otomatik yayın kapalı.')}

@app.get('/api/admin/instagram-readiness')
def instagram_readiness(authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yönetici bağlantı hazırlığını görebilir')
    required=('INSTAGRAM_CLIENT_ID','INSTAGRAM_CLIENT_SECRET','INSTAGRAM_REDIRECT_URI')
    configured={name:bool(os.environ.get(name,'').strip()) for name in required}
    account=instagram_stored_status(u['business_id'])
    enabled=os.environ.get('INSTAGRAM_OAUTH_ENABLED')=='1'
    return {
        'configured':configured,'oauth_enabled':enabled,
        'ready':all(configured.values()) and enabled,
        'connected':account['connected'],'status':account['status'],
        'auto_publish':False,
        'steps':[
            'Instagram profesyonel hesabı ve Meta uygulama izinleri doğrulanmalı.',
            'Instagram Hesabını Bağla ile Meta izin ekranı tamamlanmalı.',
            'Bağlantı sonrası canlı Meta API doğrulaması ve kontrollü yayın testi yapılmalı.'
        ],
        'message':('Yerel Instagram bağlantı kaydı mevcut; Meta API doğrulaması yapılmadı.'
                   if account['connected'] else 'Instagram hesabı henüz bağlanmadı.')
    }

# OAuth state handshake only. No provider tokens are exchanged or stored in this pilot.
# Do not enable an OAuth redirect until the real Meta API integration is implemented.
class OAuthStateRequest(BaseModel):
    confirmation:bool=False

@app.post('/api/admin/instagram/oauth-state')
def instagram_oauth_state(request:OAuthStateRequest, authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yöneticiler bağlantı başlatabilir')
    if not request.confirmation:
        raise HTTPException(422,'Bağlantı hazırlığı için yönetici onayı gerekli')
    state=secrets.token_urlsafe(32)
    digest=hashlib.sha256(state.encode()).hexdigest()
    expires=(datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat()
    with db() as c:
        c.execute('DELETE FROM oauth_states WHERE expires < ?', (datetime.now(timezone.utc).isoformat(),))
        c.execute('INSERT INTO oauth_states(state_hash,business_id,user_id,expires) VALUES (?,?,?,?)',(digest,u['business_id'],u['id'],expires))
    return {'state':state,'expires_at':expires,'connected':False,'authorization_url':None,
            'message':'Tek kullanımlık doğrulama oluşturuldu. Gerçek Meta yönlendirmesi henüz etkin değil.'}

# Generates the official Instagram Login consent URL only. It never connects an account.
# The callback and token exchange are intentionally NOT enabled until live credentials
# and an approved HTTPS redirect have been validated with Meta.
@app.post('/api/admin/instagram/authorization-url')
def instagram_authorization_url(request:OAuthStateRequest, authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yöneticiler bağlantı başlatabilir')
    if not request.confirmation:
        raise HTTPException(422,'Yönetici onayı gerekli')
    client_id=os.environ.get('INSTAGRAM_CLIENT_ID','').strip()
    redirect_uri=os.environ.get('INSTAGRAM_REDIRECT_URI','').strip()
    parsed=urlparse(redirect_uri)
    if not client_id.isdigit() or not redirect_uri or parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise HTTPException(503,'Instagram uygulama kimliği veya HTTPS yönlendirme adresi yapılandırılmadı')
    state=secrets.token_urlsafe(32)
    expires=(datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat()
    with db() as c:
        c.execute('DELETE FROM oauth_states WHERE expires < ?', (datetime.now(timezone.utc).isoformat(),))
        c.execute('INSERT INTO oauth_states(state_hash,business_id,user_id,expires) VALUES (?,?,?,?)',
                  (hashlib.sha256(state.encode()).hexdigest(),u['business_id'],u['id'],expires))
    params={'client_id':client_id,'redirect_uri':redirect_uri,
            'scope':'instagram_business_basic,instagram_business_content_publish',
            'response_type':'code','state':state}
    return {'authorization_url':'https://www.instagram.com/oauth/authorize?'+urlencode(params),
            'expires_at':expires,'connected':False,
            'message':'Meta izin ekranı için bağlantı hazır. İzinlerden sonra bağlantı durumu kontrol edilecek.'}

class OAuthStateConsume(BaseModel):
    state:str=Field(min_length=30,max_length=256)

@app.post('/api/admin/instagram/oauth-state/verify')
def instagram_oauth_state_verify(request:OAuthStateConsume,authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yöneticiler bağlantı doğrulayabilir')
    digest=hashlib.sha256(request.state.encode()).hexdigest()
    with db() as c:
        changed=c.execute("UPDATE oauth_states SET consumed=1 WHERE state_hash=? AND business_id=? AND user_id=? AND consumed=0 AND expires>?",
            (digest,u['business_id'],u['id'],datetime.now(timezone.utc).isoformat())).rowcount
    if changed!=1:
        raise HTTPException(400,'Doğrulama geçersiz, kullanılmış veya süresi dolmuş')
    return {'state_verified':True,'connected':False,'message':'Yerel state doğrulandı; Meta hesabı henüz bağlanmadı.'}

# Explicit opt-in callback: code exchange is disabled by default.
from fastapi.responses import HTMLResponse

@app.get('/api/instagram/callback', response_class=HTMLResponse)
def instagram_callback(state:str='', code:str='', error:str=''):
    if os.environ.get('INSTAGRAM_OAUTH_ENABLED') != '1':
        raise HTTPException(503, 'Instagram bağlantısı canlı ortamda etkinleştirilmedi')
    if not state or len(state) > 256:
        raise HTTPException(400, 'Geçersiz bağlantı doğrulaması')
    digest = hashlib.sha256(state.encode()).hexdigest()
    with db() as c:
        row = c.execute('SELECT business_id FROM oauth_states WHERE state_hash=? AND consumed=0 AND expires>?',
                        (digest,datetime.now(timezone.utc).isoformat())).fetchone()
        if not row:
            raise HTTPException(400, 'Bağlantı süresi dolmuş veya bağlantı kullanılmış')
        changed = c.execute('UPDATE oauth_states SET consumed=1 WHERE state_hash=? AND consumed=0', (digest,)).rowcount
        if changed != 1:
            raise HTTPException(400, 'Bağlantı daha önce kullanılmış')
        business_id = row['business_id']
    if error or not code or len(code) > 4096:
        raise HTTPException(400, 'Instagram yetkilendirmesi reddedildi veya kod eksik')
    client_id = os.environ.get('INSTAGRAM_CLIENT_ID', '').strip()
    secret = os.environ.get('INSTAGRAM_CLIENT_SECRET', '').strip()
    redirect_uri = os.environ.get('INSTAGRAM_REDIRECT_URI', '').strip()
    if not client_id.isdigit() or not secret or not redirect_uri.startswith('https://'):
        raise HTTPException(503, 'Meta OAuth yapılandırması eksik')
    try:
        token_data = exchange_code(code, client_id, secret, redirect_uri)
        long_lived = exchange_long_lived_token(token_data['access_token'], secret)
        expires_at = (datetime.now(timezone.utc) + timedelta(seconds=long_lived['expires_in'])).isoformat()
        with db() as c:
            save_token(c, business_id, 'instagram', long_lived['access_token'])
            c.execute('INSERT INTO instagram_accounts(business_id,instagram_user_id,connected_at,expires_at) VALUES(?,?,?,?) ON CONFLICT(business_id) DO UPDATE SET instagram_user_id=excluded.instagram_user_id,connected_at=excluded.connected_at,expires_at=excluded.expires_at',
                (business_id,token_data['user_id'],datetime.now(timezone.utc).isoformat(),expires_at))
    except Exception:
        raise HTTPException(502, 'Instagram bağlantısı tamamlanamadı; sistem kayıtlarını kontrol edin')
    return HTMLResponse('<!doctype html><html lang="tr"><meta charset="utf-8"><title>SocialPlan</title><body><h1>Instagram hesabı bağlandı</h1><p>Uygulamaya dönebilirsiniz. Otomatik paylaşım henüz etkin değildir.</p></body></html>', headers={'Cache-Control':'no-store','Referrer-Policy':'no-referrer'})

@app.get('/api/admin/instagram/account')
def instagram_account_status(authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yönetici hesap durumunu görebilir')
    return instagram_stored_status(u['business_id'])

@app.post('/api/admin/instagram/refresh')
def refresh_instagram_account(authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yönetici bağlantıyı yenileyebilir')
    if os.environ.get('INSTAGRAM_OAUTH_ENABLED') != '1':
        raise HTTPException(503,'Instagram bağlantısı etkin değil')
    with db() as c:
        row=c.execute('SELECT expires_at FROM instagram_accounts WHERE business_id=?',(u['business_id'],)).fetchone()
        if row is None:
            raise HTTPException(404,'Bağlı Instagram hesabı yok')
        try:
            token=load_token(c,u['business_id'],'instagram')
        except RuntimeError:
            raise HTTPException(503,'Şifreli bağlantı anahtarına erişilemiyor')
        if not token:
            raise HTTPException(409,'Instagram erişim anahtarı bulunamadı')
        if row['expires_at']:
            expiry=datetime.fromisoformat(row['expires_at'])
            age_remaining=expiry-datetime.now(timezone.utc)
            if age_remaining.total_seconds()<=0:
                raise HTTPException(409,'Token süresi dolmuş; hesabı yeniden bağlayın')
            if age_remaining > timedelta(days=53):
                raise HTTPException(409,'Token henüz yenileme için yeterince eski değil')
    try:
        refreshed=refresh_long_lived_token(token)
    except Exception:
        raise HTTPException(502,'Meta token yenileme işlemi başarısız')
    expires=(datetime.now(timezone.utc)+timedelta(seconds=refreshed['expires_in'])).isoformat()
    with db() as c:
        # Do not overwrite a token that was disconnected or replaced while the API request ran.
        latest=load_token(c,u['business_id'],'instagram')
        exists=c.execute('SELECT 1 FROM instagram_accounts WHERE business_id=?',(u['business_id'],)).fetchone()
        if not exists or latest!=token:
            raise HTTPException(409,'Instagram bağlantısı işlem sırasında değişti')
        save_token(c,u['business_id'],'instagram',refreshed['access_token'])
        c.execute('UPDATE instagram_accounts SET expires_at=? WHERE business_id=?',(expires,u['business_id']))
    return {'refreshed':True,'expires_at':expires,'auto_publish':False,
            'message':'Token yenilendi; Instagram paylaşımı henüz etkin değil.'}

@app.delete('/api/admin/instagram/account')
def disconnect_instagram_account(authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yönetici bağlantıyı kaldırabilir')
    with db() as c:
        delete_token(c,u['business_id'],'instagram')
        c.execute('DELETE FROM instagram_accounts WHERE business_id=?',(u['business_id'],))
        c.execute('DELETE FROM oauth_states WHERE business_id=?',(u['business_id'],))
    return {'connected':False,'message':'Yerel bağlantı kaldırıldı. Meta tarafındaki uygulama izni ayrıca kaldırılmalıdır.'}

@app.get('/manifest.webmanifest')
def manifest():return FileResponse(ROOT/'static'/'manifest.webmanifest',media_type='application/manifest+json')

@app.get('/sw.js')
def service_worker():return FileResponse(ROOT/'static'/'sw.js',media_type='application/javascript',headers={'Cache-Control':'no-store'})

@app.get('/icon.svg')
def icon():return FileResponse(ROOT/'static'/'icon.svg',media_type='image/svg+xml')

@app.get('/api/admin/publishing-queue')
def publishing_queue(authorization:str|None=Header(default=None)):
    """Read-only approval queue. Never implies Instagram publication."""
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yönetici yayın kuyruğunu görebilir')
    now=datetime.now(timezone.utc)
    with db() as c:
        rows=c.execute("SELECT p.id,p.caption,p.scheduled_at,p.media_id,m.mime FROM posts p LEFT JOIN media m ON m.id=p.media_id AND m.business_id=p.business_id WHERE p.business_id=? AND p.status='approved' ORDER BY p.scheduled_at,p.id",(u['business_id'],)).fetchall()
    items=[]
    for row in rows:
        r=dict(row)
        try:
            due=datetime.fromisoformat(r['scheduled_at']).astimezone(timezone.utc)<=now
        except (ValueError,TypeError):
            due=False
        blockers=[]
        if r['media_id'] is None:
            blockers.append('Medya eklenmemiş')
        elif r['mime'] not in ('image/jpeg','image/png','image/webp','video/mp4'):
            blockers.append('Desteklenmeyen medya türü')
        blockers.append('Instagram bağlantısı ve herkese açık medya adresi kurulmadı')
        items.append({'id':r['id'],'caption':r['caption'],'scheduled_at':r['scheduled_at'],'due':due,'media_id':r['media_id'],'media_mime':r['mime'],'ready_for_instagram':False,'blockers':blockers,'published':False})
    return {'connected':False,'auto_publish_enabled':False,'items':items,'count':len(items)}


@app.post('/api/admin/publishing-queue/{post_id}/prepare',status_code=201)
def prepare_publish_job(post_id:int,authorization:str|None=Header(default=None)):
    """Idempotent, local-only publication preparation. Does NOT call Meta."""
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yönetici yayın hazırlığı yapabilir')
    now=datetime.now(timezone.utc).isoformat()
    with db() as c:
        post=c.execute("SELECT p.status,p.media_id,p.scheduled_at,m.mime FROM posts p LEFT JOIN media m ON m.id=p.media_id AND m.business_id=p.business_id WHERE p.id=? AND p.business_id=?",(post_id,u['business_id'])).fetchone()
        if not post:raise HTTPException(404,'İçerik bulunamadı')
        if post['status']!='approved':raise HTTPException(409,'İçerik yönetici onaylı değil')
        if not post['media_id'] or post['mime'] not in ('image/jpeg','image/png','image/webp','video/mp4'):
            raise HTTPException(422,'Yayın için geçerli medya gerekli')
        existing=c.execute('SELECT id,status FROM publish_jobs WHERE business_id=? AND post_id=?',(u['business_id'],post_id)).fetchone()
        if existing:
            return {'job_id':existing['id'],'status':existing['status'],'created':False,'published':False}
        cursor=c.execute('INSERT INTO publish_jobs(business_id,post_id,status,created_at,updated_at) VALUES(?,?,?,?,?)',(u['business_id'],post_id,'pending',now,now))
        record_audit(c,u,'publish_prepared',post_id)
        return {'job_id':cursor.lastrowid,'status':'pending','created':True,'published':False}

@app.get('/api/admin/publishing-jobs')
def list_publish_jobs(authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':raise HTTPException(403,'Yalnız yönetici görebilir')
    with db() as c:
        jobs=[dict(r) for r in c.execute('SELECT id,post_id,status,created_at,updated_at,last_error FROM publish_jobs WHERE business_id=? ORDER BY id DESC',(u['business_id'],)).fetchall()]
    return {'jobs':jobs,'auto_publish_enabled':False,'message':'Hazırlık kayıtlarıdır; Instagram gönderimi yapılmaz.'}

# 4.7: durable, manual publication lifecycle. No outbound Meta calls are made here.
class PublishTransition(BaseModel):
    event: str
    meta_id: str | None = None
    note: str | None = None

@app.post('/api/admin/publishing-jobs/{job_id}/transition')
def transition_publish_job(job_id:int, request:PublishTransition, authorization:str|None=Header(default=None)):
    """Operator reconciliation after separately verified Meta API operations.

    Never automatically retry an ambiguous publish. A reported success is a manual
    attestation, not proof of a successful Meta API call.
    """
    u=current(authorization)
    if u['role']!='admin':
        raise HTTPException(403,'Yalnız yönetici yayın durumunu değiştirebilir')
    transitions={
        ('pending','container_created'):'container_created',
        ('container_created','container_ready'):'container_ready',
        ('container_ready','publish_started'):'publishing',
        ('publishing','publish_confirmed'):'published',
        ('publishing','publish_uncertain'):'uncertain',
        ('pending','cancel'):'cancelled',
        ('container_created','cancel'):'cancelled',
        ('container_ready','cancel'):'cancelled',
        ('uncertain','publish_confirmed'):'published',
        ('uncertain','manual_cancel'):'cancelled',
    }
    now=datetime.now(timezone.utc).isoformat()
    with db() as c:
        row=c.execute('SELECT status FROM publish_jobs WHERE id=? AND business_id=?', (job_id,u['business_id'])).fetchone()
        if not row:raise HTTPException(404,'Yayın işi bulunamadı')
        status=transitions.get((row['status'],request.event))
        if not status:raise HTTPException(409,'Bu durum geçişine izin verilmiyor')
        if request.event in ('container_created','publish_confirmed') and not (request.meta_id and request.meta_id.isdigit()):
            raise HTTPException(422,'Meta kimliği gerekli')
        if request.event=='manual_cancel' and not request.note:
            raise HTTPException(422,'Belirsiz yayın sonucunu kapatmak için açıklama gerekli')
        c.execute('UPDATE publish_jobs SET status=?,updated_at=?,last_error=? WHERE id=? AND business_id=?',
                  (status,now,(request.note or None) if status in ('uncertain','cancelled') else None,job_id,u['business_id']))
        c.execute('INSERT INTO publish_job_events(job_id,business_id,actor_id,event,meta_id,note,created_at) VALUES(?,?,?,?,?,?,?)',
                  (job_id,u['business_id'],u['id'],request.event,request.meta_id,request.note,now))
        record_audit(c,u,'publish_'+request.event,None)
    return {'job_id':job_id,'status':status,'meta_id_recorded':bool(request.meta_id),'verified_by_meta':False}

@app.get('/api/admin/publishing-jobs/{job_id}/history')
def publish_job_history(job_id:int,authorization:str|None=Header(default=None)):
    u=current(authorization)
    if u['role']!='admin':raise HTTPException(403,'Yalnız yönetici görebilir')
    with db() as c:
        if not c.execute('SELECT 1 FROM publish_jobs WHERE id=? AND business_id=?',(job_id,u['business_id'])).fetchone():
            raise HTTPException(404,'Yayın işi bulunamadı')
        rows=c.execute('SELECT event,meta_id,note,created_at FROM publish_job_events WHERE job_id=? AND business_id=? ORDER BY id',(job_id,u['business_id'])).fetchall()
    return {'events':[dict(r) for r in rows]}

@app.get('/api/admin/publishing-jobs/interrupted')
def interrupted_publish_jobs(authorization: str | None = Header(default=None)):
    """Read-only crash/ambiguity triage. Does not contact Meta or retry publishing."""
    u = current(authorization)
    if u['role'] != 'admin':
        raise HTTPException(403, 'Yalnız yönetici görebilir')
    from publish_runner import inspect_interrupted_jobs
    with db() as c:
        jobs = inspect_interrupted_jobs(c, business_id=u['business_id'])
    for job in jobs:
        status = job['status']
        job['requires_manual_review'] = True
        job['auto_retry_allowed'] = False
        job['guidance'] = (
            'Meta üzerinde yayın sonucunu doğrulayın; aynı içeriği yeniden göndermeyin.'
            if status in ('publishing', 'uncertain') else
            'Meta konteyner durumunu ve yayın geçmişini kontrol edin; otomatik tekrar yok.'
        )
    return {'jobs': jobs, 'count': len(jobs), 'read_only': True, 'meta_verified': False}
