"""One-shot scheduled backup job. Run via an external scheduler (cron/Render Cron)."""
import json
import os
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from offsite_backup import run

def notify_failure(record, sender=None):
    """Send a failure alert to an operator-configured HTTPS webhook.

    Never log the webhook URL (it can contain a secret token).
    """
    url = os.environ.get('SOCIALPLAN_ALERT_WEBHOOK', '').strip()
    if not url:
        return False
    if not url.startswith('https://'):
        raise ValueError('Uyarı webhook adresi HTTPS olmalı')
    body = json.dumps({'event': 'socialplan.backup.failed', 'time_utc': record['time_utc'],
                       'message': 'SocialPlan harici yedekleme başarısız oldu'}, ensure_ascii=False).encode()
    request = urllib.request.Request(url, data=body, headers={'Content-Type': 'application/json'}, method='POST')
    (sender or urllib.request.urlopen)(request, timeout=10)
    return True


def execute(runner=run, status_file=None, notifier=notify_failure):
    path = Path(status_file or os.environ.get('SOCIALPLAN_BACKUP_STATUS', '/tmp/socialplan-backup-status.json'))
    now = datetime.now(timezone.utc).isoformat()
    try:
        result = runner()
        if not result.get('verified'):
            raise RuntimeError('Uzak yedek doğrulanmadı')
        record = {'time_utc': now, 'status': 'success', 'key': result['key'], 'verified': True}
    except Exception as exc:
        record = {'time_utc': now, 'status': 'failure', 'error': str(exc), 'verified': False}
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(record, ensure_ascii=False), encoding='utf-8')
    temporary.replace(path)
    if record['status'] == 'failure':
        try:
            record['alert_sent'] = bool(notifier(record))
        except Exception:
            record['alert_sent'] = False
            record['alert_error'] = 'Uyarı iletilemedi; zamanlayıcı hata kodunu kontrol edin'
        temporary.write_text(json.dumps(record, ensure_ascii=False), encoding='utf-8')
        temporary.replace(path)
    return record

if __name__ == '__main__':
    result = execute()
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result['status'] == 'success' else 1)
