import importlib, sys
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from fastapi.testclient import TestClient

def test_instagram_authorization_url_is_gated_and_scoped(tmp_path,monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_DB',str(tmp_path/'db.sqlite3'))
    monkeypatch.setenv('SOCIALPLAN_MEDIA',str(tmp_path/'media'))
    monkeypatch.delenv('SOCIALPLAN_REQUIRE_PERSISTENT',raising=False)
    monkeypatch.delenv('INSTAGRAM_CLIENT_ID',raising=False)
    monkeypatch.delenv('INSTAGRAM_REDIRECT_URI',raising=False)
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    sys.modules.pop('app',None)
    app=importlib.import_module('app')
    with TestClient(app.app) as c:
        c.post('/api/register',json={'business':'RHM','email':'admin@example.com','password':'Password2026Strong!'})
        token=c.post('/api/login',json={'email':'admin@example.com','password':'Password2026Strong!'}).json()['token']
        auth={'Authorization':'Bearer '+token}
        endpoint='/api/admin/instagram/authorization-url'
        assert c.post(endpoint,json={'confirmation':True}).status_code==401
        assert c.post(endpoint,json={'confirmation':False},headers=auth).status_code==422
        assert c.post(endpoint,json={'confirmation':True},headers=auth).status_code==503
        monkeypatch.setenv('INSTAGRAM_CLIENT_ID','123456789')
        monkeypatch.setenv('INSTAGRAM_REDIRECT_URI','http://example.com/callback')
        assert c.post(endpoint,json={'confirmation':True},headers=auth).status_code==503
        monkeypatch.setenv('INSTAGRAM_REDIRECT_URI','https://example.com/instagram/callback')
        result=c.post(endpoint,json={'confirmation':True},headers=auth)
        assert result.status_code==200,result.text
        data=result.json()
        assert data['connected'] is False
        parsed=urlparse(data['authorization_url'])
        assert parsed.scheme=='https' and parsed.netloc=='www.instagram.com' and parsed.path=='/oauth/authorize'
        query=parse_qs(parsed.query)
        assert query['client_id']==['123456789']
        assert query['scope']==['instagram_business_basic,instagram_business_content_publish']
        assert query['redirect_uri']==['https://example.com/instagram/callback']
        assert len(query['state'][0])>=30
        assert c.post('/api/admin/instagram/oauth-state/verify',json={'state':query['state'][0]},headers=auth).status_code==200
        assert c.post('/api/admin/instagram/oauth-state/verify',json={'state':query['state'][0]},headers=auth).status_code==400
