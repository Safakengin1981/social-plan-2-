"""Offline restore to a NEW empty directory. Stop the app before using restored data."""
import argparse
import os
import shutil
import tempfile
import zipfile
from pathlib import Path
from backup import verify


def restore(archive, destination):
    archive = Path(archive).resolve()
    destination = Path(destination).resolve()
    verify(archive)
    if destination.exists():
        raise FileExistsError('Destination already exists; choose a NEW directory')
    if destination == Path('/') or destination == Path.home():
        raise ValueError('Unsafe destination')
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.socialplan-restore-', dir=destination.parent))
    try:
        with zipfile.ZipFile(archive) as z:
            manifest = verify(archive)
            for name in manifest['files']:
                # verify() already validates entry names and SHA-256 hashes.
                target = staging / ('socialplan.sqlite3' if name == 'database.sqlite3' else name)
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(name) as src, target.open('xb') as out:
                    shutil.copyfileobj(src, out)
        staging.rename(destination)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return destination


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Restore a verified SocialPlan archive into a NEW directory')
    parser.add_argument('archive')
    parser.add_argument('destination', help='New, nonexistent directory; NEVER a live data directory')
    args = parser.parse_args()
    print('Restored to:', restore(args.archive, args.destination))
