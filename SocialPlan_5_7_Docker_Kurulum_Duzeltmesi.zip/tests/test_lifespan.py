from fastapi.testclient import TestClient
from unittest.mock import patch
from app import app

def test_lifespan_starts_scheduler_once():
    with patch("scheduler.start") as start:
        with TestClient(app) as client:
            r=client.get("/api/health")
            assert r.status_code == 200
            assert r.json()["version"] == "5.6"
        start.assert_called_once_with()

def test_no_deprecated_startup_hooks():
    assert not app.router.on_startup
