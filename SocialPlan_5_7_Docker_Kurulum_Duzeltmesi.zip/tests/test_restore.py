import importlib.util
import sqlite3
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]

def load(name):
    spec=importlib.util.spec_from_file_location(name, ROOT / (name+'.py'))
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def test_restore_roundtrip(tmp_path, monkeypatch):
    backup=load('backup')
    monkeypatch.setattr(backup, 'DB', tmp_path/'original.sqlite3')
    monkeypatch.setattr(backup, 'MEDIA', tmp_path/'original_media')
    with sqlite3.connect(backup.DB) as c:
        c.execute('CREATE TABLE example (value TEXT)')
        c.execute('INSERT INTO example VALUES (?)', ('hello',))
    backup.MEDIA.mkdir()
    (backup.MEDIA/'photo.jpg').write_bytes(b'fake media')
    archive=backup.create(tmp_path/'backup.zip')
    restore=load('restore')
    target=restore.restore(archive, tmp_path/'recovered')
    with sqlite3.connect(target/'socialplan.sqlite3') as c:
        assert c.execute('SELECT value FROM example').fetchone()[0]=='hello'
    assert (target/'media'/'photo.jpg').read_bytes()==b'fake media'
    with pytest.raises(FileExistsError):
        restore.restore(archive, target)

def test_restore_rejects_corruption(tmp_path, monkeypatch):
    import zipfile
    backup=load('backup')
    monkeypatch.setattr(backup, 'DB', tmp_path/'original.sqlite3')
    monkeypatch.setattr(backup, 'MEDIA', tmp_path/'missing_media')
    with sqlite3.connect(backup.DB) as c: c.execute('CREATE TABLE test (x INTEGER)')
    archive=backup.create(tmp_path/'good.zip')
    with zipfile.ZipFile(archive) as src, zipfile.ZipFile(tmp_path/'bad.zip', 'w') as dst:
        for name in src.namelist():
            data=src.read(name)
            if name=='database.sqlite3': data=b'corrupted'
            dst.writestr(name,data)
    restore=load('restore')
    with pytest.raises(ValueError): restore.restore(tmp_path/'bad.zip',tmp_path/'target')
    assert not (tmp_path/'target').exists()
