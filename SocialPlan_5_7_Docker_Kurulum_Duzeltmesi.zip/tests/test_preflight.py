from preflight import check

def test_preflight_missing_settings_are_rejected():
    result=check({})
    assert len(result)==8 and not any(x['ok'] for x in result)

def test_preflight_valid_settings():
    env={'SOCIALPLAN_REQUIRE_PERSISTENT':'1','SOCIALPLAN_DB':'/var/data/db.sqlite3',
         'SOCIALPLAN_MEDIA':'/var/data/media','SOCIALPLAN_BACKUP_STATUS':'/var/data/backup.json',
         'SOCIALPLAN_AUTO_BACKUP':'1','SOCIALPLAN_BACKUP_BUCKET':'test-bucket',
         'AWS_ACCESS_KEY_ID':'test-key','AWS_SECRET_ACCESS_KEY':'test-secret',
         'SOCIALPLAN_ALERT_WEBHOOK':'https://example.test/notify'}
    assert all(x['ok'] for x in check(env))
