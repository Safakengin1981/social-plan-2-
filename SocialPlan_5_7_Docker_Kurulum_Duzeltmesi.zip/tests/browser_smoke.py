"""Local real-browser smoke test. Run: python tests/browser_smoke.py"""
import os, sys, tempfile, subprocess, time, socket
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    with socket.socket() as s:
        s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    env={**os.environ,'SOCIALPLAN_DB':str(Path(tmp)/'test.sqlite3'),'SOCIALPLAN_MEDIA':str(Path(tmp)/'media')}
    proc=subprocess.Popen([sys.executable,'-m','uvicorn','app:app','--host','127.0.0.1','--port',str(port)],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    try:
        import urllib.request
        for _ in range(70):
            try:
                urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=.3)
                break
            except Exception: time.sleep(.15)
        else: raise RuntimeError('Server did not start')
        with sync_playwright() as p:
            browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
            page=browser.new_page(viewport={'width':390,'height':844})
            errors=[]
            page.on('pageerror',lambda e: errors.append(str(e)))
            page.goto(f'http://127.0.0.1:{port}/',wait_until='networkidle')
            page.locator('#email').fill('pilot@example.com')
            page.locator('#password').fill('PilotSifre2026!!')
            page.locator('#business').fill('RHM Teras TEST')
            page.locator('#registerBtn').click()
            page.get_by_text('İşletme oluşturuldu.',exact=False).wait_for(timeout=10000)
            page.locator('#loginBtn').click()
            page.locator('#workspace').wait_for(state='visible',timeout=10000)
            assert 'RHM Teras TEST' in page.locator('#who').inner_text()
            page.locator('[data-tab="create"]').click()
            page.locator('#caption').fill('Tarayıcı testi gönderisi')
            page.locator('#scheduled').fill('2026-12-01T15:00')
            page.locator('#saveBtn').click()
            page.get_by_text('Tarayıcı testi gönderisi').wait_for(timeout=10000)
            page.get_by_role('button',name='Onayla').click()
            page.get_by_text('Onaylı').wait_for(timeout=10000)
            page.locator('#logoutBtn').click()
            page.locator('#auth').wait_for(state='visible',timeout=10000)
            assert not errors,errors
            browser.close()
            print('PASS: Chromium mobile viewport, register, login, create, approve, logout; no JS page errors')
    finally:
        proc.terminate()
        try: proc.wait(timeout=5)
        except subprocess.TimeoutExpired: proc.kill()
