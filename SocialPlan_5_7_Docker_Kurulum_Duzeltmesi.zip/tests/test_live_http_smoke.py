"""Actual loopback HTTP smoke test (not a browser test)."""
import json, os, socket, subprocess, sys, time, urllib.request, urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_real_http_restart_persists_business_and_post(tmp_path):
    sock=socket.socket(); sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]; sock.close()
    env=os.environ.copy(); env.update(SOCIALPLAN_DB=str(tmp_path/'db.sqlite3'),SOCIALPLAN_MEDIA=str(tmp_path/'media'),SOCIALPLAN_AUTO_BACKUP='0',SOCIALPLAN_REQUIRE_PERSISTENT='0')
    base=f'http://127.0.0.1:{port}'
    def request(path, method='GET', data=None, token=None):
        payload=json.dumps(data).encode() if data is not None else None
        headers={'Content-Type':'application/json'}
        if token: headers['Authorization']='Bearer '+token
        with urllib.request.urlopen(urllib.request.Request(base+path,data=payload,headers=headers,method=method),timeout=3) as r:
            return r.status, r.read(),r.headers
    def start():
        p=subprocess.Popen([sys.executable,'-m','uvicorn','app:app','--host','127.0.0.1','--port',str(port)],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        for _ in range(80):
            if p.poll() is not None: raise AssertionError('Sunucu erken kapandı: '+p.stderr.read().decode()[-2000:])
            try:
                if request('/api/health')[0]==200: return p
            except (urllib.error.URLError, TimeoutError): time.sleep(.1)
        p.kill(); raise AssertionError('HTTP sunucusu başlatılamadı')
    def stop(p):
        p.terminate()
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:p.kill();p.wait()
    p=start()
    try:
        assert request('/')[0]==200
        assert request('/app.js')[0]==200
        status,_,_=request('/api/register','POST',{'business':'HTTP Test','email':'admin@sample.test','password':'very-long-password-123'})
        assert status in (200,201)
        token=json.loads(request('/api/login','POST',{'email':'admin@sample.test','password':'very-long-password-123'})[1])['token']
        status,body,_=request('/api/posts','POST',{'caption':'Kalici test kaydi','scheduled_at':'2027-01-01T12:00:00+03:00'},token)
        assert status in (200,201),body
    finally: stop(p)
    p=start()
    try:
        token=json.loads(request('/api/login','POST',{'email':'admin@sample.test','password':'very-long-password-123'})[1])['token']
        status,body,_=request('/api/posts',token=token)
        assert status==200 and b'Kalici test kaydi' in body
    finally: stop(p)
