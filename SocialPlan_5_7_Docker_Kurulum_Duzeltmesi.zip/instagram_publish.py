"""Instagram Graph publishing transport. No automatic execution or retry.

The caller must supply a publicly reachable HTTPS media URL and a valid token.
On network ambiguity, do not repeat publish_media blindly.
"""
import json
import urllib.parse
import urllib.request

BASE = 'https://graph.instagram.com'

class PublishUncertain(Exception):
    """A request may have reached Meta; manual reconciliation required."""

class MetaPublishError(Exception):
    pass


def _request(path, fields, *, method='POST', opener=None):
    if not path.startswith('/') or '//' in path or '?' in path:
        raise ValueError('Geçersiz Meta API yolu')
    opener = opener or urllib.request.urlopen
    data = urllib.parse.urlencode(fields).encode('utf-8')
    url = BASE + path
    req = urllib.request.Request(url + ('?' + data.decode() if method == 'GET' else ''),
                                 data=data if method == 'POST' else None,
                                 method=method)
    try:
        with opener(req, timeout=20) as response:
            if response.status != 200:
                raise MetaPublishError('Meta API HTTP hatası')
            result = json.loads(response.read(65536))
    except (TimeoutError, OSError) as exc:
        raise PublishUncertain('Meta yanıtı alınamadı; otomatik tekrar denemeyin') from exc
    if not isinstance(result, dict) or 'error' in result:
        raise MetaPublishError('Meta API işlemi reddetti')
    return result


def create_image_container(user_id, image_url, caption, token, *, opener=None):
    if not str(user_id).isdigit() or not token:
        raise ValueError('Instagram hesap kimliği veya token eksik')
    if not image_url.startswith('https://'):
        raise ValueError('Instagram için herkese açık HTTPS medya adresi gerekli')
    result = _request(f'/{user_id}/media', {'image_url':image_url,'caption':caption,'access_token':token},opener=opener)
    if not str(result.get('id','')).isdigit():
        raise MetaPublishError('Meta medya konteyner kimliği döndürmedi')
    return str(result['id'])


def get_container_status(container_id, token, *, opener=None):
    if not str(container_id).isdigit() or not token:
        raise ValueError('Geçersiz konteyner veya token')
    result = _request(f'/{container_id}',{'fields':'status_code,status','access_token':token},method='GET',opener=opener)
    status = result.get('status_code')
    if status not in ('IN_PROGRESS','FINISHED','ERROR','EXPIRED','PUBLISHED'):
        raise MetaPublishError('Bilinmeyen medya durumu')
    return status


def publish_container(user_id, container_id, token, *, opener=None):
    if not str(user_id).isdigit() or not str(container_id).isdigit() or not token:
        raise ValueError('Geçersiz Instagram yayın bilgisi')
    result = _request(f'/{user_id}/media_publish',{'creation_id':container_id,'access_token':token},opener=opener)
    if not str(result.get('id','')).isdigit():
        raise PublishUncertain('Meta yanıtında yayın kimliği yok; tekrar göndermeyin')
    return str(result['id'])
