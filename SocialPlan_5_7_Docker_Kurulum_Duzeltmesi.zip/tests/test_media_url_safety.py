import pytest
from publish_runner import validate_media_url

@pytest.mark.parametrize("url", [
    "https://127.0.0.1/image.jpg", "https://169.254.169.254/latest/meta-data",
    "https://10.0.0.2/a", "https://[::1]/a", "https://localhost./a",
    "https://private.internal/a", "https://example.com:8443/a",
    "https://user:pass@example.com/a", "http://example.com/a",
])
def test_reject_unsafe_media_urls(url):
    with pytest.raises(ValueError): validate_media_url(url)

def test_allow_https_domain():
    assert validate_media_url("https://cdn.example.com/photo.jpg") == "https://cdn.example.com/photo.jpg"
