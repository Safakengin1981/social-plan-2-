"""Chromium mobile end-to-end UI with REAL FastAPI app via in-process ASGI bridge.
No external network/localhost. Tests UI, real auth, persistence, approval, logout.
"""
import os, sys, tempfile, importlib
from pathlib import Path
from fastapi.testclient import TestClient
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    os.environ['SOCIALPLAN_DB']=str(Path(tmp)/'socialplan.sqlite3')
    os.environ['SOCIALPLAN_MEDIA']=str(Path(tmp)/'media')
    os.environ.pop('SOCIALPLAN_REQUIRE_PERSISTENT',None)
    sys.path.insert(0,str(ROOT))
    sys.modules.pop('app',None)
    app=importlib.import_module('app')
    with TestClient(app.app) as client, sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':390,'height':844},service_workers='block')
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        def bridge(route):
            req=route.request
            path=req.url.split('socialplan.test',1)[-1]
            body=req.post_data_buffer
            headers={k:v for k,v in req.headers.items() if k.lower() not in ('host','content-length','accept-encoding')}
            response=client.request(req.method,path,headers=headers,content=body,follow_redirects=False)
            outgoing={k:v for k,v in response.headers.items() if k.lower() not in ('content-encoding','transfer-encoding','content-length')}
            route.fulfill(status=response.status_code,headers=outgoing,body=response.content)
        page.route('https://socialplan.test/**',bridge)
        page.goto('https://socialplan.test/',wait_until='load')
        page.locator('#business').fill('RHM Tarayıcı Test')
        page.locator('#email').fill('browser@example.test')
        page.locator('#password').fill('BrowserTest2026!!')
        page.locator('#registerBtn').click()
        page.get_by_text('İşletme oluşturuldu.',exact=False).wait_for(timeout=15000)
        page.locator('#loginBtn').click()
        page.locator('#workspace').wait_for(state='visible',timeout=15000)
        page.locator('[data-tab="create"]').click()
        page.locator('#caption').fill('Gerçek API ile tarayıcı testi')
        page.locator('#scheduled').fill('2026-12-01T15:00')
        page.locator('#saveBtn').click()
        page.get_by_text('Gerçek API ile tarayıcı testi').wait_for(timeout=15000)
        page.get_by_role('button',name='Onayla').click()
        page.get_by_text('Onaylı').wait_for(timeout=15000)
        assert client.get('/api/health').status_code==200
        page.locator('#logoutBtn').click()
        page.locator('#auth').wait_for(state='visible',timeout=15000)
        assert not errors,errors
        browser.close()
print('PASS: Chromium 390px + real FastAPI/SQLite: register, login, create, approve, logout; zero page errors')
