import importlib
import os
import sys
from fastapi.testclient import TestClient

def test_publish_prepare_is_idempotent_and_isolated(tmp_path, monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_DB',str(tmp_path/'test.db'))
    monkeypatch.setenv('SOCIALPLAN_MEDIA',str(tmp_path/'media'))
    sys.modules.pop('app',None)
    appmod=importlib.import_module('app')
    client=TestClient(appmod.app)
    def register(b,email):
        r=client.post('/api/register',json={'business':b,'email':email,'password':'StrongPassword123!'})
        assert r.status_code in (200,201),r.text
        login=client.post('/api/login',json={'email':email,'password':'StrongPassword123!'})
        assert login.status_code==200,login.text
        return {'Authorization':'Bearer '+login.json()['token']}
    a=register('Firma A','a45@example.com')
    b=register('Firma B','b45@example.com')
    assert client.post('/api/admin/publishing-queue/999/prepare',headers=a).status_code==404
    assert client.get('/api/admin/publishing-jobs',headers=b).json()['jobs']==[]
    # Approved post without media cannot enter publication queue.
    r=client.post('/api/posts',headers=a,json={'caption':'test','scheduled_at':'2030-11-01T15:00:00+00:00'})
    assert r.status_code==201,r.text
    post_id=r.json()['id']
    assert client.post(f'/api/admin/publishing-queue/{post_id}/prepare',headers=a).status_code==409
    assert client.post(f'/api/posts/{post_id}/approve',headers=a).status_code==200
    assert client.post(f'/api/admin/publishing-queue/{post_id}/prepare',headers=a).status_code==422
    assert client.post(f'/api/admin/publishing-queue/{post_id}/prepare',headers=b).status_code==404
    assert client.get('/api/admin/publishing-jobs',headers=a).json()['jobs']==[]
