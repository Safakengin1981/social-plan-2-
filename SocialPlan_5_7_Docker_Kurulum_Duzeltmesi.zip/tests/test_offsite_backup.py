import os
import sqlite3
from pathlib import Path
from unittest.mock import patch
import offsite_backup

class MemoryS3:
    def __init__(self): self.objects={}
    def upload_file(self, filename, bucket, key, ExtraArgs=None):
        assert ExtraArgs == {'ServerSideEncryption': 'AES256'}
        self.objects[(bucket,key)]=Path(filename).read_bytes()
    def download_file(self,bucket,key,filename):
        Path(filename).write_bytes(self.objects[(bucket,key)])

def test_upload_and_download_verification(tmp_path):
    db=tmp_path/'test.sqlite3'
    with sqlite3.connect(db) as conn: conn.execute('CREATE TABLE example (id integer)')
    with patch('backup.DB',db),patch('backup.MEDIA',tmp_path/'media'):
        fake=MemoryS3()
        result=offsite_backup.run('test-bucket',client=fake)
        assert result['verified'] is True
        assert len(fake.objects)==1

def test_missing_bucket(monkeypatch):
    monkeypatch.delenv('SOCIALPLAN_BACKUP_BUCKET',raising=False)
    try: offsite_backup.run(client=MemoryS3())
    except ValueError as exc: assert 'BUCKET' in str(exc)
    else: raise AssertionError('Missing bucket must fail')

def test_corrupted_download_rejected(tmp_path):
    db=tmp_path/'test.sqlite3'
    with sqlite3.connect(db) as conn: conn.execute('CREATE TABLE example (id integer)')
    class Corrupt(MemoryS3):
        def download_file(self,bucket,key,filename): Path(filename).write_bytes(b'not a zip')
    with patch('backup.DB',db),patch('backup.MEDIA',tmp_path/'media'):
        try: offsite_backup.run('test-bucket',client=Corrupt())
        except Exception: pass
        else: raise AssertionError('Corrupted download must fail')
