import os,sys,subprocess,tempfile,textwrap
from pathlib import Path

def test_queue_is_read_only_and_isolated():
    root=Path(__file__).resolve().parents[1]
    script=textwrap.dedent('''
    from fastapi.testclient import TestClient
    from datetime import datetime,timezone,timedelta
    import app
    c=TestClient(app.app)
    def register(b,e):
        assert c.post('/api/register',json={'business':b,'email':e,'password':'long-password-123'}).status_code==201
        token=c.post('/api/login',json={'email':e,'password':'long-password-123'}).json()['token']
        return {'Authorization':'Bearer '+token}
    a=register('İşletme A','a@example.test')
    b=register('İşletme B','b@example.test')
    future=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
    pid=c.post('/api/posts',json={'caption':'Onaylı gönderi','scheduled_at':future},headers=a).json()['id']
    assert c.post(f'/api/posts/{pid}/approve',headers=a).status_code==200
    assert c.get('/api/admin/publishing-queue').status_code==401
    q=c.get('/api/admin/publishing-queue',headers=a)
    assert q.status_code==200
    assert q.json()['count']==1
    assert q.json()['items'][0]['published'] is False
    assert q.json()['items'][0]['ready_for_instagram'] is False
    assert q.json()['items'][0]['due'] is False
    assert 'Medya eklenmemiş' in q.json()['items'][0]['blockers']
    assert c.get('/api/admin/publishing-queue',headers=b).json()['items']==[]
    assert c.get('/api/posts',headers=a).json()[0]['status']=='approved'
    assert c.post('/api/members',json={'email':'editor@example.test','password':'long-password-123','role':'editor'},headers=a).status_code==201
    e={'Authorization':'Bearer '+c.post('/api/login',json={'email':'editor@example.test','password':'long-password-123'}).json()['token']}
    assert c.get('/api/admin/publishing-queue',headers=e).status_code==403
    ''')
    with tempfile.TemporaryDirectory() as d:
        env=os.environ.copy()
        env['SOCIALPLAN_DB']=str(Path(d)/'data.db')
        env['SOCIALPLAN_MEDIA']=str(Path(d)/'media')
        env.pop('SOCIALPLAN_REQUIRE_PERSISTENT',None)
        result=subprocess.run([sys.executable,'-c',script],cwd=root,env=env,capture_output=True,text=True)
        assert result.returncode==0,result.stderr
