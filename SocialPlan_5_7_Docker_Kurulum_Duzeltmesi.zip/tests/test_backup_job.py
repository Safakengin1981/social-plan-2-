import json
from backup_job import execute

def test_success(tmp_path):
    target = tmp_path / 'status.json'
    result = execute(lambda: {'verified': True, 'key': 'daily/test.zip'}, target)
    assert result['status'] == 'success'
    assert json.loads(target.read_text())['key'] == 'daily/test.zip'

def test_failure_is_recorded(tmp_path):
    def failing():
        raise RuntimeError('cloud unreachable')
    target = tmp_path / 'status.json'
    result = execute(failing, target)
    assert result['status'] == 'failure'
    assert 'cloud unreachable' in json.loads(target.read_text())['error']

def test_unverified_backup_fails(tmp_path):
    result = execute(lambda: {'verified': False, 'key': 'x'}, tmp_path / 'status.json')
    assert result['status'] == 'failure'
