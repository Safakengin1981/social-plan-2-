import importlib, os, sys, tempfile, csv, io
from pathlib import Path
from datetime import datetime, timezone, timedelta
from fastapi.testclient import TestClient


def test_csv_formula_protection_and_tenant_isolation():
    with tempfile.TemporaryDirectory() as d:
        os.environ['SOCIALPLAN_DB'] = str(Path(d) / 'db.sqlite3')
        os.environ['SOCIALPLAN_MEDIA'] = str(Path(d) / 'media')
        os.environ.pop('SOCIALPLAN_REQUIRE_PERSISTENT', None)
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        sys.modules.pop('app', None)
        app = importlib.import_module('app')
        with TestClient(app.app) as c:
            def account(email):
                assert c.post('/api/register', json={'business':'Test', 'email':email, 'password':'safe-password-123'}).status_code == 201
                token = c.post('/api/login', json={'email':email, 'password':'safe-password-123'}).json()['token']
                return {'Authorization': 'Bearer ' + token}
            a = account('a@example.test')
            b = account('b@example.test')
            when = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
            captions = ['=1+1', '+SUM(1,2)', '-1+2', '@SUM(1,2)', '  =IMPORTXML(1,2)', '\t=1+1', 'Normal açıklama']
            for caption in captions:
                assert c.post('/api/posts', headers=a, json={'caption':caption, 'scheduled_at':when}).status_code == 201
            text = c.get('/api/posts/export.csv', headers=a).content.decode('utf-8-sig')
            rows = list(csv.reader(io.StringIO(text)))
            assert [r[1] for r in rows[1:]] == ["'" + x for x in captions[:-1]] + [captions[-1]]
            assert len(list(csv.reader(io.StringIO(c.get('/api/posts/export.csv', headers=b).content.decode('utf-8-sig'))))) == 1
            assert c.get('/api/posts/export.csv').status_code == 401
