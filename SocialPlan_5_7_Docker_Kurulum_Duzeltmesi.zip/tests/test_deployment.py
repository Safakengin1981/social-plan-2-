from pathlib import Path
import os
import subprocess
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]

def test_blueprint_persistent_disk():
    config = yaml.safe_load((ROOT / 'render.yaml').read_text())
    service = config['services'][0]
    assert service['disk']['mountPath'] == '/var/data'
    assert service['plan'] != 'free'
    env = {x['key']: x['value'] for x in service['envVars']}
    assert env['SOCIALPLAN_DB'].startswith('/var/data/')
    assert env['SOCIALPLAN_MEDIA'].startswith('/var/data/')
    assert env['SOCIALPLAN_REQUIRE_PERSISTENT'] == '1'
    assert service['healthCheckPath'] == '/api/ready'

def test_startup_refuses_unmounted_disk(tmp_path):
    env = os.environ.copy()
    env.update(SOCIALPLAN_REQUIRE_PERSISTENT='1', SOCIALPLAN_DB='/var/data/socialplan.sqlite3', SOCIALPLAN_MEDIA='/var/data/media')
    result = subprocess.run([sys.executable, '-c', 'import app'], cwd=ROOT, env=env, capture_output=True, text=True)
    assert result.returncode != 0
    assert 'Kalıcı disk' in result.stderr

def test_ready_endpoint(tmp_path):
    env = os.environ.copy()
    env.pop('SOCIALPLAN_REQUIRE_PERSISTENT', None)
    env['SOCIALPLAN_DB'] = str(tmp_path / 'db.sqlite3')
    env['SOCIALPLAN_MEDIA'] = str(tmp_path / 'media')
    result = subprocess.run([sys.executable, '-c', 'from fastapi.testclient import TestClient; from app import app; r=TestClient(app).get("/api/ready"); assert r.status_code==200, r.text'], cwd=ROOT, env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
