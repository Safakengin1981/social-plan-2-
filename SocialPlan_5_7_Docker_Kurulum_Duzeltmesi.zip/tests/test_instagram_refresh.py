import sys
from datetime import datetime, timezone, timedelta
from fastapi.testclient import TestClient
from cryptography.fernet import Fernet

def test_refresh_is_scoped_and_saves_new_token(tmp_path,monkeypatch):
    monkeypatch.setenv('SOCIALPLAN_DB',str(tmp_path/'test.sqlite'))
    monkeypatch.setenv('SOCIALPLAN_MEDIA',str(tmp_path/'media'))
    monkeypatch.setenv('SOCIALPLAN_TOKEN_KEY',Fernet.generate_key().decode())
    monkeypatch.setenv('INSTAGRAM_OAUTH_ENABLED','1')
    sys.modules.pop('app',None)
    import app
    client=TestClient(app.app)
    def register(name,email):
        assert client.post('/api/register',json={'business':name,'email':email,'password':'LongPassword123!'}).status_code in (200,201)
        r=client.post('/api/login',json={'email':email,'password':'LongPassword123!'})
        return {'Authorization':'Bearer '+r.json()['token']}
    a=register('Business A','a@example.org')
    b=register('Business B','b@example.org')
    assert client.post('/api/admin/instagram/refresh',headers=a).status_code==404
    from token_vault import save_token,load_token
    with app.db() as c:
        save_token(c,1,'instagram','old-token')
        c.execute('INSERT INTO instagram_accounts(business_id,instagram_user_id,connected_at,expires_at) VALUES(?,?,?,?)',
            (1,'123',datetime.now(timezone.utc).isoformat(),(datetime.now(timezone.utc)+timedelta(days=3)).isoformat()))
    monkeypatch.setattr(app,'refresh_long_lived_token',lambda token: {'access_token':'new-token','expires_in':5184000})
    assert client.post('/api/admin/instagram/refresh',headers=b).status_code==404
    r=client.post('/api/admin/instagram/refresh',headers=a)
    assert r.status_code==200,r.text
    assert r.json()['refreshed'] is True and 'new-token' not in r.text
    with app.db() as c:
        assert load_token(c,1,'instagram')=='new-token'
        expiry=c.execute('SELECT expires_at FROM instagram_accounts WHERE business_id=1').fetchone()[0]
        assert datetime.fromisoformat(expiry)>datetime.now(timezone.utc)+timedelta(days=50)
    assert client.post('/api/admin/instagram/refresh',headers=a).status_code==409
    with app.db() as c:
        c.execute('UPDATE instagram_accounts SET expires_at=? WHERE business_id=1',((datetime.now(timezone.utc)-timedelta(days=1)).isoformat(),))
    assert client.post('/api/admin/instagram/refresh',headers=a).status_code==409

def test_refresh_network_response_validation(monkeypatch):
    import instagram_oauth
    class FakeResponse:
        status=200
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def read(self,limit):return b'{"access_token":"new-token","expires_in":5184000}'
    seen=[]
    def fake_open(request,timeout):
        seen.append(request.full_url)
        return FakeResponse()
    monkeypatch.setattr(instagram_oauth.urllib.request,'urlopen',fake_open)
    assert instagram_oauth.refresh_long_lived_token('old-token')['expires_in']==5184000
    assert 'ig_refresh_token' in seen[0]
    assert instagram_oauth.exchange_long_lived_token('short-token','secret')['access_token']=='new-token'
    assert 'ig_exchange_token' in seen[1]
