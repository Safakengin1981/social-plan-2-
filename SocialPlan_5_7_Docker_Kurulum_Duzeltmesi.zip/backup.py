"""SocialPlan offline backup utility. Run against a persistent volume; copy archives off-host."""
import argparse
import hashlib
import json
import os
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = Path(os.environ.get('SOCIALPLAN_DB', str(ROOT / 'data' / 'socialplan.sqlite3')))
MEDIA = Path(os.environ.get('SOCIALPLAN_MEDIA', str(DB.parent / 'media')))

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def create(destination):
    if not DB.is_file():
        raise FileNotFoundError(f'Database not found: {DB}')
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        snapshot = Path(td) / 'database.sqlite3'
        with sqlite3.connect(DB) as src, sqlite3.connect(snapshot) as dst:
            src.backup(dst)
            result = dst.execute('PRAGMA integrity_check').fetchone()[0]
            if result != 'ok':
                raise RuntimeError(f'SQLite integrity check failed: {result}')
        entries = {'database.sqlite3': snapshot.read_bytes()}
        if MEDIA.exists():
            for p in sorted(MEDIA.rglob('*')):
                if p.is_file() and not p.is_symlink():
                    entries['media/' + p.relative_to(MEDIA).as_posix()] = p.read_bytes()
        manifest = {'format': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
                    'files': {name: sha256(data) for name, data in entries.items()}}
        entries['manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode()
        with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            for name, data in entries.items():
                z.writestr(name, data)
    verify(destination)
    return destination

def verify(archive):
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Duplicate archive entries')
        manifest = json.loads(z.read('manifest.json'))
        if manifest.get('format') != 1 or 'database.sqlite3' not in manifest.get('files', {}):
            raise ValueError('Invalid backup manifest')
        for name, expected in manifest['files'].items():
            if name.startswith('/') or '..' in Path(name).parts or (name != 'database.sqlite3' and not name.startswith('media/')):
                raise ValueError('Unsafe backup entry')
            if sha256(z.read(name)) != expected:
                raise ValueError(f'Checksum mismatch: {name}')
        if set(names) != set(manifest['files']) | {'manifest.json'}:
            raise ValueError('Unexpected backup entries')
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'verify.sqlite3'
            path.write_bytes(z.read('database.sqlite3'))
            with sqlite3.connect(path) as conn:
                if conn.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                    raise ValueError('Database integrity check failed')
    return manifest

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Create or verify SocialPlan backup archive')
    parser.add_argument('action', choices=['create', 'verify'])
    parser.add_argument('archive')
    args = parser.parse_args()
    if args.action == 'create':
        print('Created:', create(args.archive))
    else:
        print('Verified:', json.dumps(verify(args.archive), ensure_ascii=False))
